const questoes = [
    {
      pergunta: "Antes, eram apenas as grandes cidades que se apresentavam como o império da técnica, objeto de modificações, suspensões, acréscimos, cada vez mais sofisticadas e carregadas de artifício. Esse mundo artificial inclui, hoje, o mundo rural. Considerando a transformação mencionada no texto uma consequência socioespacial que caracteriza o atual mundo rural brasileiro é",
      respostas: {
        a: "a redução do processo de concentração de terras",
        b: "o aumento do aproveitamento de solos menos férteis.",
        c: "a ampliação do isolamento do espaço rural.",
        d: "a estagnação da fronteira agrícola do país.",
        e: "a diminuição do nível de emprego formal."
      },
      respostaCorreta: "b",
      explicacao: "Revolução Verde é o conceito dado para o momento histórico geográfico em que se deu um processo de maquinização e modernização do espaço agrário. A intensificação das sementes transgênicas e a maior especialização dos fertilizantes e agrotóxicos possibilitou o cultivo de gêneros agrícolas de maneira independente a fatores como o clima ou as especificidades do solo. A mão de obra física e braçal foi substituída por grandes máquinas para o cultivo das monoculturas. Milton Santos, em seu texto, faz referência a esse momento onde o “império da técnica” para de se limitar só a cidade, extrapolando as fronteiras da tecnologia. Por ser um processo elitizado, houve na verdade aumento da concentração de terras, avanço da fronteira agrícola e empregabilidade no setor de serviços, especializada e qualificada."
    },
    {
      pergunta: "A evolução do processo de transformação de matériasprimas em produtos acabados ocorreu em três estágios: artesanato, manufatura e maquinofatura. Um desses estágios foi o artesanato, em que se",
      respostas: {
        a: "trabalhava conforme o ritmo das máquinas e de maneira padronizada.",
        b: "trabalhava geralmente sem o uso de máquinas e de modo diferente do modelo de produção em série.",
        c: "empregavam fontes de energia abundantes para o funcionamento das máquinas.",
        d: "realizava parte da produção por cada operário, com uso de máquinas e trabalho assalariado.",
        e: "faziam interferências do processo produtivo por técnicos e gerentes com vistas a determinar o ritmode produção."
      },
      respostaCorreta: "b",
      explicacao: "A questão faz referência aos momentos iniciais da industrialização, da primeira revolução industrial e dos modos produtivos que antecederam e originaram-a. O artesanato era a maneira manual de se produzir, conhecendo todos os aspectos da produção e produzindo em quantidade menor por dia. Esses ofícios artesanais muitas vezes eram passados de geração em geração. "
    },
    {
      pergunta: "Durante o Estado Novo, os encarregados da propaganda procuraram aperfeiçoar-se na arte da empolgação e envolvimento das “multidões” através das mensagens políticas. Nesse tipo de discurso, o significado das palavras importa pouco, pois, como declarou Goebbels, “não falamos para dizer alguma coisa, mas para obter determinado efeito”. O controle sobre os meios de comunicação foi uma marca do Estado Novo, sendo fundamental à propaganda política, na medida em que visava",
      respostas: {
        a: "conquistar o apoio popular na legitimação do novo governo.",
        b: "ampliar o envolvimento das multidões nas decisões políticas.",
        c: "aumentar a oferta de informações públicas para a sociedade civil.",
        d: "estender a participação democrática dos meios de comunicação no Brasil.",
        e: "alargar o entendimento da população sobre as intenções do novo governo."
      },
      respostaCorreta: "a",
      explicacao: "A propaganda política era sempre ufanista e paternalista, sendo usada para cooptar o povo para o projeto nacionalista do governo."
    },
    {
      pergunta: "Quando a Corte chegou ao Rio de Janeiro, a Colônia tinha acabado de passar por uma explosão populacional. Em pouco mais de cem anos, o número de habitantes aumentara dez vezes. A alteração demográfica destacada no período teve como causa a atividade",
      respostas: {
        a: "cafeeira, com a atração da imigração europeia.",
        b: "industrial, com a intensificação do êxodo rural.",
        c: "mineradora, com a ampliação do tráfico africano.",
        d: "canavieira, com o aumento do apresamento indígena.",
        e: "manufatureira, com a incorporação do trabalho assalariado."
      },
      respostaCorreta: "c",
      explicacao: "A mineração tornou-se a principal atividade econômica na Colônia, o que fez aumentar a importação de negros escravizados."
    },

    {
      pergunta: "“Devo estar chegando perto do centro da Terra. Deixe ver: deve ter sido mais de seis mil quilômetros, por aí...” (como se vê, Alice tinha aprendido uma porção de coisas desse tipo na escola, e embora essa não fosse uma oportunidade lá muito boa de demonstrar conhecimentos, já que não havia ninguém por perto para escutá-la, em todo caso era bom praticar um pouco) “... sim, deve ser mais ou menos essa a distância... mas então qual seria a latitude ou longitude em que estou?” (Alice não tinha a menor ideia do que fosse latitude ou longitude, mas achou que eram palavras muito imponentes). O texto descreve uma confusão da personagem em relação",
      respostas: {
        a: "ao tipo de projeção cartográfica.",
        b: "aos contornos dos fusos horários.",
        c: "à localização do norte magnético.",
        d: "aos referenciais de posição relativa.",
        e: "às distorções das formas continentais."
      },
      respostaCorreta: "d",
      explicacao: "Os conceitos de latitude e longitude, desconhecidos por Alice, são referenciais de posição relativa: Latitude: coordenada geográfica que varia de 0º a 90º, partindo da Linha do Equador no sentido norte ou sul (linhas horizontais). Longitude: coordenada geográfica que varia de 0º a 180º, partindo do Meridiano de Greenwich, no sentido leste ou oeste (linhas verticais)."
    },
    {
      pergunta: " A diversidade de atividades relacionadas ao setor terciário reforça a tendência mais geral de desindustrialização de muitos dos países desenvolvidos sem que estes, contudo, percam o comando da economia. Essa mudança implica nova divisão internacional do trabalho, que não é mais apoiada na clara segmentação setorial das atividades econômicas. Nesse contexto, o fenômeno descrito tem como um de seus resultados a",
      respostas: {
        a: "saturação do setor secundário.",
        b: "ampliação dos direitos laborais.",
        c: "bipolarização do poder geopolítico.",
        d: "consolidação do domínio tecnológico.",
        e: "primarização das exportações globais."
      },
      respostaCorreta: "d",
      explicacao: "Com o acúmulo de tecnologia e conhecimento, os países industrializados mantêm a dianteira através de suas marcas e dos royalties."
    },
    {
      pergunta: "A moralidade, Bentham exortava, não é uma questão de agradar a Deus, muito menos de fidelidade a regras abstratas. A moralidade é a tentativa de criar a maior quantidade de felicidade possível neste mundo. Ao decidir o que fazer, deveríamos, portanto, perguntar qual curso de conduta promoveria a maior quantidade de felicidade para todos aqueles que serão afetados. Os parâmetros da ação indicados no texto estão em conformidade com uma",
      respostas: {
        a: "fundamentação científica de viés positivista.",
        b: "convenção social de orientação normativa.",
        c: "transgressão comportamental religiosa.",
        d: "racionalidade de caráter pragmático.",
        e: "inclinação de natureza passional."
      },
      respostaCorreta: "d",
      explicacao: "Os ideais iluministas trazem consigo a racionalidade e a Razão como força revolucionária ou de negação à perspectiva medieval de submeter a razão à fé. O pensador inglês Jeremy Bentham (1748-1832), como um defensor do utilitarismo, propõe que a racionalidade esteja ancorada em sua relação com a prática e a utilidade, reforçando o caráter pragmático da razão."
    },
    {
      pergunta: "Art. 231. São reconhecidos aos índios sua organização social, costumes, línguas, crenças e tradições, e os direitos originários sobre as terras que tradicionalmente ocupam, competindo à União demarcá-las, proteger e fazer respeitar todos os seus bens. A persistência das reivindicações relativas à aplicação desse preceito normativo tem em vista a vinculação histórica fundamental entre",
      respostas: {
        a: "etnia e miscigenação racial.",
        b: "sociedade e igualdade jurídica.",
        c: "espaço e sobrevivência cultural.",
        d: "progresso e educação ambiental.",
        e: "bem-estar e modernização econômica."
      },
      respostaCorreta: "c",
      explicacao: "No trecho da Constituição, o direito ao território (espaço) é apresentado em seu vínculo (como necessário) para a sobrevivência cultural dos povos indígenas. A perda do direito ao território é compreendida como um risco para a “organização social, costumes, línguas, crenças e tradições” específicos dos distintos grupos."
    },
    {
      pergunta: "Manta que costura causos e histórias no seio de uma família serve de metáfora da memória em obra escrita por autora portuguesa O que poderia valer mais do que a manta para aquela família? Quadros de pintores famosos? Joias de rainha? Palácios? Uma manta feita de centenas de retalhos de roupas velhas aquecia os pés das crianças e a memória da avó, que a cada quadrado apontado por seus netos resgatava de suas lembranças uma história. Histórias fantasiosas como a do vestido com um bolso que abrigava um gnomo comedor de biscoitos; histórias de traquinagem como a do calção transformado em farrapos no dia em que o menino, que gostava de andar de bicicleta de olhos fechados, quebrou o braço; histórias de saudades, como o avental que carregou uma carta por mais de um mês... Muitas histórias formavam aquela manta. Os protagonistas eram pessoas da família, um tio, uma tia, o avô, a bisavó, ela mesma, os antigos donos das roupas. Um dia, a avó morreu, e as tias passaram a disputar a manta, todas a queriam, mais do que aos quadros, joias e palácios deixados por ela. Felizmente, as tias conseguiram chegar a um acordo, e a manta passou a ficar cada mês na casa de uma delas. E os retalhos, à medida que iam se acabando, eram substituídos por outros retalhos, e novas e antigas histórias foram sendo incorporadas à manta mais valiosa do mundo. A autora descreve a importância da manta para aquela família, ao verbalizar que “novas e antigas histórias foram sendo incorporadas à manta mais valiosa do mundo”. Essa valorização evidencia-se pela",
      respostas: {
        a: "oposição entre os objetos de valor, como joias, palácios e quadros, e a velha manta.",
        b: "descrição detalhada dos aspectos físicos da manta, como cor e tamanho dos retalhos.",
        c: "valorização da manta como objeto de herança familiar disputado por todos.",
        d: "comparação entre a manta que protege do frio e a manta que aquecia os pés das crianças.",
        e: "correlação entre os retalhos da manta e as muitas histórias de tradição oral que os formavam."
      },
      respostaCorreta: "e",
      explicacao: "Ao longo do texto é descrito como os retalhos que formavam a manta carregavam um pouco da memória da família - o pedaço do vestido, do calção, do avental: “histórias de saudades, como o avental que carregou uma carta por mais de um mês... Muitas histórias formavam aquela manta.”"
    },
    {
      pergunta: "Tenho dois seios, estas duas coxas, duas mãos que me são muito úteis, olhos escuros, estas duas sobrancelhas que preencho com maquiagem comprada por dezenove e noventa e orelhas que não aceitam bijuterias. Este corpo é um corpo faminto, dentado, cruel, capaz e violento. Movo os braços e multidões correm desesperadas. Caminho no escuro com o rosto para baixo, pois cada parte isolada de mim tem sua própria vida e não quero domá-las. Animal da caatinga. Forte demais. Engolidora de espadas e espinhos. Dizem e eu ouvi, mas depois também li, que o estado do Ceará aboliu a escravidão quatro anos antes do restante do país. Todos aqueles corpos que eram trazidos com seus dedos contados, seus calcanhares prontos e seus umbigos em fogo, todos eles foram interrompidos no porto. Um homem – dizem e eu ouvi e depois também li — liderou o levante. E todos esses corpos foram buscar outros incômodos. Foram ser incomodados.",
      respostas: {
        a: "revelam as marcas da violência de raça e de gênero na construção da identidade.",
        b: "questionam o pioneirismo do estado do Ceará no enfrentamento à escravidão.",
        c: "reproduzem padrões estéticos em busca da valorização da autoestima feminina.",
        d: "sugerem uma atmosfera onírica alinhada ao desejo de resgate da espiritualidade.",
        e: "mimetizam, na paisagem, os corpos transformados pela violência da escravidão."
      },
      respostaCorreta: "a",
      explicacao: "No primeiro parágrafo, a narradora, ao realizar uma descrição física sobre si mesma, revela a existência de certos padrões estéticos de gênero, como a utilização de maquiagem (“estas duas sobrancelhas que preencho com maquiagem…”) e de adornos (uso de brincos, desde que não sejam, no caso da narradora, bijuterias). No segundo parágrafo, a narradora se refere aos corpos de negros escravizados que, mesmo após a abolição da escravidão, “foram buscar outros incômodos. Foram ser incomodados”. No contexto, podemos inferir que esses corpos seguiram sendo incomodados por não se encaixarem em padrões estéticos dominantes. Dessa forma, é possível enxergar marcas de violência de gênero e de raça na construção da identidade do indivíduo."
    }, //10
    {
      pergunta: "Em 2013, houve um movimento social que ficou conhecido como Jornadas de Junho. Qual foi um dos motivos para o início dessas manifestações?",
      respostas: {
          a: "O aumento da passagem de ônibus",
          b: "A crise econômica internacional",
          c: "A aprovação da reforma da previdência",
          d: "A privatização de empresas públicas",
          e: "O aumento da taxa de juros"
      },
      respostaCorreta: "a",
      explicacao: "As manifestações começaram devido ao aumento da tarifa do transporte público nas principais cidades do país."
  },
  {
      pergunta: "No contexto da globalização, o que é a 'Aldeia Global'?",
      respostas: {
          a: "A ideia de uma sociedade sem desigualdade",
          b: "A percepção de um mundo interconectado pela mídia",
          c: "A formação de blocos econômicos regionais",
          d: "O isolamento de culturas tradicionais",
          e: "O crescimento de movimentos antiglobalização"
      },
      respostaCorreta: "b",
      explicacao: "O termo 'Aldeia Global' foi popularizado por Marshall McLuhan para descrever como a tecnologia encurtou distâncias, tornando o mundo interconectado."
  },
  {
      pergunta: "Qual é o principal bioma que predomina na região Norte do Brasil?",
      respostas: {
          a: "Cerrado",
          b: "Mata Atlântica",
          c: "Caatinga",
          d: "Pantanal",
          e: "Amazônia"
      },
      respostaCorreta: "e",
      explicacao: "A Amazônia é o bioma predominante na região Norte do Brasil, caracterizado por sua floresta tropical densa."
  },
  {
      pergunta: "Qual país europeu foi o principal colonizador do Brasil?",
      respostas: {
          a: "França",
          b: "Holanda",
          c: "Inglaterra",
          d: "Espanha",
          e: "Portugal"
      },
      respostaCorreta: "e",
      explicacao: "Portugal foi o país que colonizou o Brasil a partir de 1500."
  },
  {
      pergunta: "O Iluminismo influenciou a independência de várias nações americanas. Qual era um dos seus principais ideais?",
      respostas: {
          a: "Absolutismo monárquico",
          b: "Liberalismo econômico",
          c: "Teocracia religiosa",
          d: "Conservadorismo social",
          e: "Mercantilismo"
      },
      respostaCorreta: "b",
      explicacao: "O Iluminismo defendia o liberalismo econômico e político, promovendo liberdade individual e governança democrática."
  },
  {
      pergunta: "Em qual ano foi proclamada a independência do Brasil?",
      respostas: {
          a: "1822",
          b: "1889",
          c: "1500",
          d: "1922",
          e: "1891"
      },
      respostaCorreta: "a",
      explicacao: "A independência do Brasil foi proclamada em 7 de setembro de 1822 por Dom Pedro I."
  },
  {
      pergunta: "O Tratado de Tordesilhas, assinado em 1494, dividia o mundo entre dois países. Quais eram eles?",
      respostas: {
          a: "França e Inglaterra",
          b: "Portugal e Espanha",
          c: "Holanda e Espanha",
          d: "Inglaterra e Portugal",
          e: "Portugal e França"
      },
      respostaCorreta: "b",
      explicacao: "O Tratado de Tordesilhas foi um acordo entre Portugal e Espanha para dividir as terras descobertas fora da Europa."
  },
  {
      pergunta: "Qual foi o primeiro presidente do Brasil eleito após o fim da Ditadura Militar?",
      respostas: {
          a: "Fernando Henrique Cardoso",
          b: "Itamar Franco",
          c: "Fernando Collor",
          d: "José Sarney",
          e: "Tancredo Neves"
      },
      respostaCorreta: "c",
      explicacao: "Fernando Collor foi eleito presidente em 1989, o primeiro após o período militar."
  },
  {
    pergunta: "No dia 28 de fevereiro de 1985, era inaugurada a Estrada de Ferro Carajás, pertencente e diretamente operada pela Companhia Vale do Rio Doce (CVRD), na região Norte do país, ligando o interior ao principal porto da região, em São Luís. Por seus, aproximadamente, 900 quilômetros de linha, passam, hoje, 5 353 vagões e 100 locomotivas. A ferrovia em questão é de extrema importância para a logística do setor primário da economia brasileira, em especial para porções dos estados do Pará e Maranhão. Um argumento que destaca a importância estratégica dessa porção do território é a ",
    respostas: {
        a: "produção de energia para as principais áreas industriais do país.",
        b: "produção sustentável de recursos minerais não metálicos",
        c: "capacidade de produção de minerais metálicos.",
        d: "logística de importação de matérias-primas industriais",
        e: "produção de recursos minerais energéticos."
    },
    respostaCorreta: "c",
    explicacao: "A ferrovia em questão foi construída próximo a Serra dos Carajás, se beneficiando da exploração de mineiros de ferro, manganês, cobre, ouro e níquel. Ela também realiza o importante papel de transportar trabalhadores migrantes para as áreas de desenvolvimento no Norte e no Nordeste, e transporte demais mercadorias como a soja e demais commodities."
},
  {
    pergunta: "Qual foi o impacto da chegada da Família Real portuguesa ao Brasil em 1808?",
    respostas: {
        a: "Desenvolvimento da indústria têxtil",
        b: "Abertura dos portos às nações amigas",
        c: "Exploração de ouro em Minas Gerais",
        d: "Início do ciclo da borracha",
        e: "Construção de Brasília"
    },
    respostaCorreta: "b",
    explicacao: "A chegada da Família Real em 1808 levou à abertura dos portos brasileiros para o comércio internacional, especialmente com a Inglaterra."
},//20
{
  pergunta: "Qual foi o principal motivo da Revolta da Vacina, ocorrida em 1904 no Rio de Janeiro?",
  respostas: {
      a: "Aumento dos impostos sobre alimentos",
      b: "Obrigações militares impostas à população",
      c: "Imposição da vacinação obrigatória contra a varíola",
      d: "Criação de leis de segregação racial",
      e: "Aumento do preço dos transportes públicos"
  },
  respostaCorreta: "c",
  explicacao: "A Revolta da Vacina ocorreu devido à imposição da vacinação obrigatória contra a varíola, gerando revolta popular."
},
{
  pergunta: "O que foi a Revolução Industrial?",
  respostas: {
      a: "O movimento de independência das colônias americanas",
      b: "A substituição das manufaturas pelo sistema fabril",
      c: "A formação de grandes impérios coloniais na África",
      d: "A expansão da Igreja Católica na Europa",
      e: "O desenvolvimento da agricultura no Brasil"
  },
  respostaCorreta: "b",
  explicacao: "A Revolução Industrial foi marcada pela introdução de máquinas e o surgimento do sistema fabril, substituindo a produção manual."
},
{
  pergunta: "Qual foi o principal objetivo do Tratado de Petrópolis, assinado em 1903?",
  respostas: {
      a: "Definir as fronteiras do Brasil com a Argentina",
      b: "Declarar a independência do Brasil",
      c: "Anexar o Acre ao território brasileiro",
      d: "Criar uma aliança econômica com o Uruguai",
      e: "Estabelecer um acordo comercial com a França"
  },
  respostaCorreta: "c",
  explicacao: "O Tratado de Petrópolis resultou na anexação do Acre ao território brasileiro, comprado da Bolívia."
},
{
  pergunta: "Como o Iluminismo influenciou a independência dos Estados Unidos?",
  respostas: {
      a: "Defendendo o aumento de impostos",
      b: "Promovendo a centralização do poder monárquico",
      c: "Encorajando a luta por liberdade e direitos individuais",
      d: "Apoiando a escravidão nas colônias",
      e: "Propondo o fortalecimento da Igreja Católica"
  },
  respostaCorreta: "c",
  explicacao: "O Iluminismo influenciou a independência dos EUA ao promover ideias de liberdade e direitos individuais."
},
{
  pergunta: "Qual foi o principal objetivo da Revolução Francesa?",
  respostas: {
      a: "Estabelecer o comunismo na França",
      b: "Abolir a escravidão nas colônias francesas",
      c: "Abolir a monarquia e estabelecer uma república",
      d: "Declarar guerra contra o Império Britânico",
      e: "Promover a expansão territorial da França"
  },
  respostaCorreta: "c",
  explicacao: "A Revolução Francesa buscou abolir a monarquia absoluta e instaurar um governo republicano."
},
{
  pergunta: "O que foi o Tratado de Versalhes, assinado em 1919?",
  respostas: {
      a: "Um acordo entre Portugal e Espanha para dividir as colônias americanas",
      b: "O tratado de paz que encerrou a Primeira Guerra Mundial",
      c: "A criação da Liga das Nações",
      d: "Um pacto de não-agressão entre Alemanha e União Soviética",
      e: "A divisão da África entre potências europeias"
  },
  respostaCorreta: "b",
  explicacao: "O Tratado de Versalhes, assinado em 1919, encerrou oficialmente a Primeira Guerra Mundial e impôs condições à Alemanha."
},
{
  pergunta: "Qual foi o principal objetivo do Movimento Diretas Já, no Brasil?",
  respostas: {
      a: "Aumentar os impostos sobre importações",
      b: "Promover a reforma agrária no Brasil",
      c: "Defender eleições diretas para a presidência",
      d: "Abolir a censura nos meios de comunicação",
      e: "Reforçar a presença militar nas fronteiras"
  },
  respostaCorreta: "c",
  explicacao: "O Movimento Diretas Já, nos anos 1980, foi um movimento popular que pedia eleições diretas para presidente no Brasil."
},
{
  pergunta: "O que foi a Guerra dos Emboabas, ocorrida no início do século XVIII?",
  respostas: {
      a: "Um conflito entre bandeirantes paulistas e forasteiros pela exploração de ouro em Minas Gerais",
      b: "Uma guerra entre Portugal e Espanha pela posse do Brasil",
      c: "Uma disputa territorial entre o Brasil e a Argentina",
      d: "Um levante indígena contra os colonizadores portugueses",
      e: "Uma revolta dos escravos contra a coroa portuguesa"
  },
  respostaCorreta: "a",
  explicacao: "A Guerra dos Emboabas foi um conflito entre paulistas e forasteiros pelo controle da exploração do ouro em Minas Gerais."
},
{
  pergunta: "Qual foi o principal motivo da Inconfidência Mineira, em 1789?",
  respostas: {
      a: "O aumento dos impostos sobre o ouro",
      b: "A abolição da escravidão no Brasil",
      c: "A descoberta de petróleo em Minas Gerais",
      d: "A proibição da produção de café",
      e: "A imposição da língua espanhola nas colônias"
  },
  respostaCorreta: "a",
  explicacao: "A Inconfidência Mineira foi motivada pelo aumento dos impostos sobre o ouro imposto pela Coroa Portuguesa."
},
{
pergunta: "Qual foi o principal fator que levou à queda do Muro de Berlim em 1989?",
respostas: {
    a: "A derrota da Alemanha na Segunda Guerra Mundial",
    b: "A pressão internacional liderada pelos Estados Unidos",
    c: "A reunificação econômica entre as Alemanhas Oriental e Ocidental",
    d: "O enfraquecimento do regime comunista e movimentos populares",
    e: "A imposição de sanções econômicas pela União Europeia"
},
respostaCorreta: "d",
explicacao: "A queda do Muro de Berlim foi resultado do enfraquecimento do regime comunista e da crescente pressão popular por liberdade."
},//30
{
pergunta: "Em que ano foi promulgada a Constituição brasileira atualmente em vigor?",
respostas: {
    a: "1946",
    b: "1967",
    c: "1988",
    d: "1993",
    e: "2002"
},
respostaCorreta: "c",
explicacao: "A Constituição atual do Brasil, também conhecida como Constituição Cidadã, foi promulgada em 1988."
},
{
pergunta: "O que representou a Batalha de Waterloo em 1815?",
respostas: {
    a: "A vitória definitiva de Napoleão Bonaparte",
    b: "A derrota final de Napoleão e o fim de seu império",
    c: "A invasão da Rússia pelas tropas francesas",
    d: "A unificação dos territórios alemães",
    e: "A criação da Liga das Nações"
},
respostaCorreta: "b",
explicacao: "A Batalha de Waterloo marcou a derrota final de Napoleão Bonaparte, encerrando seu império."
},
{
pergunta: "Qual foi a principal causa da Primeira Guerra Mundial?",
respostas: {
    a: "A corrida armamentista entre as potências europeias",
    b: "A disputa territorial na América do Sul",
    c: "O colapso econômico dos Estados Unidos",
    d: "A Revolução Russa de 1917",
    e: "A Revolução Francesa de 1789"
},
respostaCorreta: "a",
explicacao: "A corrida armamentista e as rivalidades entre as potências europeias foram as principais causas da Primeira Guerra Mundial."
},
{
pergunta: "Qual evento marcou o início da Era Vargas no Brasil?",
respostas: {
    a: "O Golpe Militar de 1964",
    b: "A Proclamação da República em 1889",
    c: "A Revolução de 1930",
    d: "A Independência do Brasil em 1822",
    e: "A Constituição de 1988"
},
respostaCorreta: "c",
explicacao: "A Era Vargas começou com a Revolução de 1930, quando Getúlio Vargas assumiu o poder no Brasil."
},
{
pergunta: "O que foi a Guerra Fria?",
respostas: {
    a: "Um conflito armado entre os Estados Unidos e a União Soviética",
    b: "Uma disputa ideológica e política entre capitalismo e comunismo",
    c: "Uma guerra civil na Europa após a Segunda Guerra Mundial",
    d: "A unificação da Alemanha Oriental e Ocidental",
    e: "O conflito entre a China e o Japão no século XX"
},
respostaCorreta: "b",
explicacao: "A Guerra Fria foi uma disputa ideológica e política entre os blocos capitalista e comunista, liderados pelos EUA e URSS."
},
{
pergunta: "Quem foi o líder do movimento de independência da Índia em 1947?",
respostas: {
    a: "Jawaharlal Nehru",
    b: "Subhas Chandra Bose",
    c: "Mahatma Gandhi",
    d: "Indira Gandhi",
    e: "Rajiv Gandhi"
},
respostaCorreta: "c",
explicacao: "Mahatma Gandhi foi o líder do movimento de independência da Índia, utilizando a resistência pacífica como método de luta."
},
{
pergunta: "O que foi o Plano Marshall, implementado após a Segunda Guerra Mundial?",
respostas: {
    a: "Um acordo de paz entre as potências europeias",
    b: "Um plano de invasão militar aos países socialistas",
    c: "Uma estratégia de reconstrução econômica da Europa Ocidental",
    d: "Uma aliança militar entre os países do Oriente Médio",
    e: "Um tratado de desarmamento nuclear"
},
respostaCorreta: "c",
explicacao: "O Plano Marshall foi um programa de ajuda econômica dos EUA para a reconstrução da Europa Ocidental após a Segunda Guerra Mundial."
},
{
pergunta: "Qual foi a principal consequência da Revolução Industrial para a sociedade europeia?",
respostas: {
    a: "O aumento da produção agrícola",
    b: "A redução da urbanização",
    c: "O surgimento do proletariado urbano",
    d: "A expansão das monarquias absolutas",
    e: "A diminuição das desigualdades sociais"
},
respostaCorreta: "c",
explicacao: "A Revolução Industrial levou ao surgimento do proletariado urbano, que trabalhava nas fábricas das cidades."
},
{
pergunta: "Qual foi o objetivo da Conferência de Berlim, realizada em 1884-1885?",
respostas: {
    a: "Estabelecer a paz entre os países europeus",
    b: "Abolir a escravidão nas colônias africanas",
    c: "Dividir o continente africano entre as potências europeias",
    d: "Unificar as colônias americanas sob uma única bandeira",
    e: "Criar um mercado comum europeu"
},
respostaCorreta: "c",
explicacao: "A Conferência de Berlim teve como objetivo dividir o continente africano entre as potências coloniais europeias."
},
{
pergunta: "Qual foi o principal motivo da Guerra do Paraguai, ocorrida entre 1864 e 1870?",
respostas: {
    a: "Disputa territorial pelo controle da Amazônia",
    b: "Conflito religioso entre Brasil e Paraguai",
    c: "Questões fronteiriças e controle sobre a navegação nos rios da região",
    d: "Revolta das populações indígenas na região",
    e: "Aliança militar entre o Brasil e a Bolívia contra o Paraguai"
},
respostaCorreta: "c",
explicacao: "A Guerra do Paraguai envolveu disputas fronteiriças e o controle da navegação fluvial na região do Rio da Prata."
},//40
{
pergunta: "Qual foi o movimento cultural que marcou a transição da Idade Média para a Idade Moderna?",
respostas: {
  a: "Barroco",
  b: "Iluminismo",
  c: "Renascimento",
  d: "Romantismo",
  e: "Modernismo"
},
respostaCorreta: "c",
explicacao: "O Renascimento foi um movimento cultural que marcou a transição para a Idade Moderna, valorizando a razão e o humanismo."
},
{
pergunta: "Qual filósofo é conhecido por sua teoria do 'Contrato Social'?",
respostas: {
  a: "Platão",
  b: "René Descartes",
  c: "Karl Marx",
  d: "Jean-Jacques Rousseau",
  e: "Michel Foucault"
},
respostaCorreta: "d",
explicacao: "Jean-Jacques Rousseau é conhecido por sua teoria do 'Contrato Social', que defendia a soberania popular."
},
{
pergunta: "O que foi a Revolução Francesa, ocorrida em 1789?",
respostas: {
  a: "Um movimento para expandir o império francês",
  b: "Uma revolução que resultou na abolição da escravidão",
  c: "Um levante popular contra o absolutismo monárquico e as desigualdades sociais",
  d: "A primeira guerra mundial liderada pela França",
  e: "Uma guerra religiosa entre católicos e protestantes na França"
},
respostaCorreta: "c",
explicacao: "A Revolução Francesa foi um movimento que visava derrubar o absolutismo monárquico e promover igualdade e liberdade."
},
{
pergunta: "Qual o principal objetivo da ONU (Organização das Nações Unidas)?",
respostas: {
  a: "Promover a supremacia militar das potências mundiais",
  b: "Regular a economia global através do comércio",
  c: "Garantir a paz e a segurança internacional",
  d: "Impor políticas ambientais a países em desenvolvimento",
  e: "Estabelecer uma moeda única para todos os países"
},
respostaCorreta: "c",
explicacao: "A ONU foi criada para promover a paz e a segurança internacional, além de fomentar a cooperação entre nações."
},
{
pergunta: "Qual evento histórico deu início à Primeira Guerra Mundial?",
respostas: {
  a: "A assinatura do Tratado de Versalhes",
  b: "A queda do Muro de Berlim",
  c: "O assassinato do arquiduque Francisco Ferdinando da Áustria",
  d: "A Revolução Industrial",
  e: "A independência dos Estados Unidos"
},
respostaCorreta: "c",
explicacao: "O assassinato do arquiduque Francisco Ferdinando, em 1914, foi o estopim para o início da Primeira Guerra Mundial."
},
{
pergunta: "O que foi a Guerra de Canudos, ocorrida no Brasil entre 1896 e 1897?",
respostas: {
  a: "Uma revolta indígena contra os colonizadores portugueses",
  b: "Um conflito entre monarquistas e republicanos no sul do Brasil",
  c: "Uma resistência liderada por Antônio Conselheiro contra o governo republicano",
  d: "A luta pela abolição da escravatura no Nordeste",
  e: "Uma guerra territorial entre o Brasil e a Argentina"
},
respostaCorreta: "c",
explicacao: "A Guerra de Canudos foi uma resistência de sertanejos liderados por Antônio Conselheiro contra o governo republicano."
},
{
pergunta: "Qual foi o principal motivo para o início da Revolução Industrial na Inglaterra?",
respostas: {
  a: "A colonização da África",
  b: "A descoberta da América",
  c: "O avanço da tecnologia e a invenção da máquina a vapor",
  d: "A Revolução Francesa",
  e: "A queda do Império Romano"
},
respostaCorreta: "c",
explicacao: "O avanço tecnológico e a invenção da máquina a vapor foram fundamentais para o início da Revolução Industrial."
},
{
pergunta: "Qual filósofo é famoso pela frase 'Penso, logo existo'?",
respostas: {
  a: "Immanuel Kant",
  b: "Friedrich Nietzsche",
  c: "Jean-Paul Sartre",
  d: "René Descartes",
  e: "John Locke"
},
respostaCorreta: "d",
explicacao: "René Descartes, um filósofo racionalista, cunhou a frase 'Penso, logo existo' como base para sua filosofia."
},
{
pergunta: "Quem foi o líder do movimento de independência dos Estados Unidos?",
respostas: {
  a: "Thomas Jefferson",
  b: "George Washington",
  c: "Benjamin Franklin",
  d: "Abraham Lincoln",
  e: "John Adams"
},
respostaCorreta: "b",
explicacao: "George Washington foi o comandante do Exército Continental e o principal líder do movimento de independência dos EUA."
},
{
pergunta: "O que foi o Apartheid na África do Sul?",
respostas: {
  a: "Um movimento de independência contra a colonização inglesa",
  b: "Uma guerra civil entre grupos tribais africanos",
  c: "Um regime de segregação racial que separava brancos e negros",
  d: "Um movimento pela igualdade de gênero no continente africano",
  e: "Uma revolução cultural promovida pelos jovens sul-africanos"
},
respostaCorreta: "c",
explicacao: "O Apartheid foi um regime de segregação racial na África do Sul, que separava brancos e negros até 1994."
},//50
{
    pergunta: "Qual é a função principal de um verbo em uma oração?",
    respostas: {
        a: "Indicar um estado ou uma ação",
        b: "Modificar um substantivo",
        c: "Estabelecer a concordância nominal",
        d: "Descrever uma característica",
        e: "Introduzir uma oração subordinada"
    },
    respostaCorreta: "a",
    explicacao: "O verbo é a classe gramatical que indica a ação, o estado ou a ocorrência no tempo."
},
{
    pergunta: "O que é uma metáfora em termos de figuras de linguagem?",
    respostas: {
        a: "Uma comparação explícita entre dois elementos",
        b: "A repetição de sons consonantais",
        c: "Uma associação entre elementos por semelhança, sem usar palavras comparativas",
        d: "Uma interrupção do discurso para fazer uma observação",
        e: "A substituição de um termo pelo seu contrário"
    },
    respostaCorreta: "c",
    explicacao: "A metáfora é uma figura de linguagem que estabelece uma relação de semelhança implícita entre dois elementos."
},
{
    pergunta: "Qual é o objetivo de um texto dissertativo-argumentativo?",
    respostas: {
        a: "Descrever um objeto ou pessoa",
        b: "Narrar uma história real ou fictícia",
        c: "Convencer o leitor de um ponto de vista",
        d: "Expor fatos e dados de forma imparcial",
        e: "Relatar uma experiência pessoal"
    },
    respostaCorreta: "c",
    explicacao: "O texto dissertativo-argumentativo busca persuadir o leitor, defendendo uma tese com argumentos."
},
{
    pergunta: "O que é um soneto?",
    respostas: {
        a: "Um poema de três versos",
        b: "Uma narrativa curta de ficção",
        c: "Uma peça teatral em um ato",
        d: "Um poema composto por 14 versos distribuídos em quatro estrofes",
        e: "Uma forma de expressão literária sem rima"
    },
    respostaCorreta: "d",
    explicacao: "O soneto é uma forma fixa de poema com 14 versos, geralmente divididos em dois quartetos e dois tercetos."
},
{
    pergunta: "Qual das alternativas abaixo é um exemplo de interjeição?",
    respostas: {
        a: "Rápido",
        b: "Ontem",
        c: "Ufa!",
        d: "Grandemente",
        e: "Ela"
    },
    respostaCorreta: "c",
    explicacao: "Interjeições são palavras que expressam emoções, sentimentos ou reações, como 'ufa!', 'oh!' ou 'ah!'."
},
{
    pergunta: "Na narrativa, qual é o papel do narrador onisciente?",
    respostas: {
        a: "Descrever apenas as ações de um personagem",
        b: "Narrar a história de acordo com o ponto de vista de um personagem específico",
        c: "Conhecer os pensamentos e sentimentos de todos os personagens",
        d: "Utilizar linguagem informal e coloquial",
        e: "Fazer parte da história como um personagem principal"
    },
    respostaCorreta: "c",
    explicacao: "O narrador onisciente é aquele que conhece todos os eventos, pensamentos e sentimentos dos personagens na narrativa."
},
{
    pergunta: "O que é a coesão textual?",
    respostas: {
        a: "O uso correto de concordância nominal",
        b: "A clareza e precisão do texto",
        c: "A ligação e conexão harmoniosa entre as partes de um texto",
        d: "A quantidade de informações apresentadas",
        e: "A análise crítica de uma obra literária"
    },
    respostaCorreta: "c",
    explicacao: "A coesão textual refere-se aos mecanismos linguísticos que garantem a conexão e continuidade entre as partes de um texto."
},
{
    pergunta: "Qual é a diferença entre um texto denotativo e um texto conotativo?",
    respostas: {
        a: "Denotativo utiliza figuras de linguagem, enquanto conotativo é literal",
        b: "Conotativo é mais objetivo, enquanto denotativo é subjetivo",
        c: "Denotativo é literal e objetivo, enquanto conotativo usa sentido figurado",
        d: "Conotativo está associado à linguagem científica, denotativo à poética",
        e: "Não há diferença entre os dois"
    },
    respostaCorreta: "c",
    explicacao: "Um texto denotativo utiliza linguagem literal, enquanto o conotativo utiliza linguagem figurada, atribuindo sentidos além do literal."
},
{
    pergunta: "O que caracteriza um texto literário?",
    respostas: {
        a: "Uso de linguagem técnica e específica",
        b: "Exposição clara de dados científicos",
        c: "Uso de linguagem artística e estética para provocar emoções",
        d: "Objetividade e precisão das informações",
        e: "Adaptação de informações para um público específico"
    },
    respostaCorreta: "c",
    explicacao: "Textos literários são marcados pela linguagem estética e pela capacidade de provocar emoções e reflexões no leitor."
},
{
    pergunta: "O que é um advérbio?",
    respostas: {
        a: "Uma palavra que modifica um verbo, um adjetivo ou outro advérbio",
        b: "Uma palavra que substitui um substantivo",
        c: "Uma palavra que indica a quantidade de um substantivo",
        d: "Uma palavra que liga orações ou palavras entre si",
        e: "Uma palavra que especifica a relação de tempo ou lugar"
    },
    respostaCorreta: "a",
    explicacao: "Advérbios são palavras que modificam verbos, adjetivos ou outros advérbios, indicando modo, tempo, lugar, intensidade, etc."
},//60
{
    pergunta: "Qual é a maior floresta tropical do mundo?",
    respostas: {
        a: "Floresta Amazônica",
        b: "Floresta do Congo",
        c: "Floresta Boreal",
        d: "Floresta Atlântica",
        e: "Floresta Tundra"
    },
    respostaCorreta: "a",
    explicacao: "A Floresta Amazônica é a maior floresta tropical do mundo, abrangendo partes de vários países da América do Sul."
},
{
    pergunta: "Qual é o rio mais extenso do mundo?",
    respostas: {
        a: "Rio Amazonas",
        b: "Rio Nilo",
        c: "Rio Yangtze",
        d: "Rio Mississippi",
        e: "Rio Ganges"
    },
    respostaCorreta: "b",
    explicacao: "O Rio Nilo é frequentemente considerado o rio mais extenso do mundo, com cerca de 6.650 km de comprimento."
},
{
    pergunta: "Qual é o continente mais populoso do mundo?",
    respostas: {
        a: "África",
        b: "América do Norte",
        c: "Ásia",
        d: "Europa",
        e: "Oceania"
    },
    respostaCorreta: "c",
    explicacao: "A Ásia é o continente mais populoso, abrigando mais da metade da população mundial."
},
{
    pergunta: "Qual país possui a maior extensão territorial do mundo?",
    respostas: {
        a: "Canadá",
        b: "China",
        c: "Estados Unidos",
        d: "Rússia",
        e: "Brasil"
    },
    respostaCorreta: "d",
    explicacao: "A Rússia é o maior país do mundo em extensão territorial, cobrindo mais de 17 milhões de km²."
},
{
    pergunta: "O que caracteriza um clima tropical?",
    respostas: {
        a: "Invernos rigorosos e verões quentes",
        b: "Quatro estações bem definidas",
        c: "Temperaturas elevadas e chuvas abundantes durante o ano todo",
        d: "Baixas temperaturas e precipitações de neve",
        e: "Clima seco com longos períodos de seca"
    },
    respostaCorreta: "c",
    explicacao: "O clima tropical é caracterizado por altas temperaturas e chuvas abundantes durante todo o ano, típico das regiões próximas ao equador."
},
{
    pergunta: "Qual é a capital da Austrália?",
    respostas: {
        a: "Sydney",
        b: "Melbourne",
        c: "Canberra",
        d: "Brisbane",
        e: "Perth"
    },
    respostaCorreta: "c",
    explicacao: "Canberra é a capital da Austrália e foi escolhida como um compromisso entre Sydney e Melbourne."
},
{
    pergunta: "O que são placas tectônicas?",
    respostas: {
        a: "Camadas de atmosfera terrestre",
        b: "Fragmentos da crosta terrestre que se movem sobre o manto",
        c: "Caminhos de água subterrânea",
        d: "Rochas sedimentares formadas pela erosão",
        e: "Áreas de vegetação densa"
    },
    respostaCorreta: "b",
    explicacao: "As placas tectônicas são fragmentos da crosta terrestre que flutuam sobre o manto e são responsáveis por fenômenos como terremotos e formação de montanhas."
},
{
    pergunta: "Qual é a maior cadeia de montanhas do mundo?",
    respostas: {
        a: "Cordilheira dos Andes",
        b: "Montanhas Rochosas",
        c: "Himalaias",
        d: "Alpes",
        e: "Appalachians"
    },
    respostaCorreta: "c",
    explicacao: "Os Himalaias são a maior cadeia de montanhas do mundo e abrigam o Monte Everest, o pico mais alto do planeta."
},
{
    pergunta: "Qual é o principal bioma do Brasil?",
    respostas: {
        a: "Cerrado",
        b: "Caatinga",
        c: "Pampa",
        d: "Mata Atlântica",
        e: "Amazônia"
    },
    respostaCorreta: "e",
    explicacao: "A Amazônia é o principal bioma do Brasil, caracterizado por sua biodiversidade e importância ecológica."
},
{
    pergunta: "O que é um rio de regime pluvial?",
    respostas: {
        a: "Rio que seca durante o verão",
        b: "Rio que recebe água principalmente da chuva",
        c: "Rio que flui em regiões polares",
        d: "Rio que se forma a partir de geleiras",
        e: "Rio que deságua em lagos"
    },
    respostaCorreta: "b",
    explicacao: "Um rio de regime pluvial é aquele que recebe a maior parte de sua água das chuvas, sendo comum em regiões tropicais."
},//70
{
    pergunta: "Quem é o autor de 'Dom Casmurro'?",
    respostas: {
        a: "José de Alencar",
        b: "Machado de Assis",
        c: "Aluísio Azevedo",
        d: "Clarice Lispector",
        e: "Jorge Amado"
    },
    respostaCorreta: "b",
    explicacao: "'Dom Casmurro' é um dos romances mais famosos de Machado de Assis, publicado em 1899."
},
{
    pergunta: "Qual é a obra que introduz o personagem Quasímodo?",
    respostas: {
        a: "A Odisseia",
        b: "Os Miseráveis",
        c: "O Corcunda de Notre-Dame",
        d: "O Conde de Monte Cristo",
        e: "A Divina Comédia"
    },
    respostaCorreta: "c",
    explicacao: "Quasímodo é o protagonista do romance 'O Corcunda de Notre-Dame', escrito por Victor Hugo e publicado em 1831."
},
{
    pergunta: "Quem escreveu a famosa obra 'O Guarani'?",
    respostas: {
        a: "José de Alencar",
        b: "Machado de Assis",
        c: "Aluísio Azevedo",
        d: "Jorge Amado",
        e: "Graciliano Ramos"
    },
    respostaCorreta: "a",
    explicacao: "'O Guarani' é uma obra de José de Alencar, publicada em 1857, que faz parte do Romantismo brasileiro."
},
{
    pergunta: "Qual é o tema principal de 'O Pequeno Príncipe'?",
    respostas: {
        a: "A guerra",
        b: "A solidão e a amizade",
        c: "A política",
        d: "A ciência",
        e: "O amor romântico"
    },
    respostaCorreta: "b",
    explicacao: "'O Pequeno Príncipe', de Antoine de Saint-Exupéry, aborda temas como a solidão, a amizade e a busca pelo sentido da vida."
},
{
    pergunta: "Quem é o autor do poema 'Cabo Verde'? ",
    respostas: {
        a: "Carlos Drummond de Andrade",
        b: "Vinícius de Moraes",
        c: "Cecília Meireles",
        d: "Adélia Prado",
        e: "Mário Quintana"
    },
    respostaCorreta: "b",
    explicacao: "'Cabo Verde' é um poema de Vinícius de Moraes, um dos mais importantes poetas e compositores brasileiros."
},
{
    pergunta: "Em que movimento literário se destaca a obra 'Memórias Póstumas de Brás Cubas'?",
    respostas: {
        a: "Romantismo",
        b: "Realismo",
        c: "Modernismo",
        d: "Simbolismo",
        e: "Barroco"
    },
    respostaCorreta: "b",
    explicacao: "'Memórias Póstumas de Brás Cubas' é um marco do Realismo, escrito por Machado de Assis e publicado em 1881."
},
{
    pergunta: "Qual é a obra mais conhecida de Clarice Lispector?",
    respostas: {
        a: "A Hora da Estrela",
        b: "Dom Casmurro",
        c: "O Guarani",
        d: "Grande Sertão: Veredas",
        e: "O Cortiço"
    },
    respostaCorreta: "a",
    explicacao: "'A Hora da Estrela' é uma das obras mais conhecidas de Clarice Lispector, publicada em 1977."
},
{
    pergunta: "Quem é o autor de 'O Alquimista'?",
    respostas: {
        a: "J.K. Rowling",
        b: "Paulo Coelho",
        c: "Gabriel García Márquez",
        d: "Mario Vargas Llosa",
        e: "Jorge Luis Borges"
    },
    respostaCorreta: "b",
    explicacao: "'O Alquimista' é um romance escrito por Paulo Coelho, publicado em 1988."
},
{
    pergunta: "Qual romance é considerado o marco inicial do Modernismo brasileiro?",
    respostas: {
        a: "O Guarani",
        b: "A Moreninha",
        c: "Macunaíma",
        d: "Os Sertões",
        e: "O Tempo e o Vento"
    },
    respostaCorreta: "c",
    explicacao: "'Macunaíma', de Mário de Andrade, é considerado o marco inicial do Modernismo brasileiro, publicado em 1928."
},
{
    pergunta: "Quem escreveu a peça 'Vestido de Noiva'?",
    respostas: {
        a: "Nelson Rodrigues",
        b: "Ariano Suassuna",
        c: "Augusto Boal",
        d: "Antônio de Almeida",
        e: "Cecília Meireles"
    },
    respostaCorreta: "a",
    explicacao: "'Vestido de Noiva' é uma das obras mais importantes de Nelson Rodrigues, estreada em 1943."
}, //80
{
    pergunta: "¿Cuál es el sinónimo de 'feliz'?",
    respostas: {
        a: "Triste",
        b: "Contento",
        c: "Enojado",
        d: "Cansado",
        e: "Aburrido"
    },
    respostaCorreta: "b",
    explicacao: "La palabra 'contento' es un sinónimo de 'feliz'."
},
{
    pergunta: "¿Qué forma verbal corresponde a 'correr'?",
    respostas: {
        a: "Caminando",
        b: "Corriendo",
        c: "Corre",
        d: "Correrá",
        e: "Corría"
    },
    respostaCorreta: "b",
    explicacao: "'Corriendo' es la forma del gerundio de 'correr'."
},
{
    pergunta: "¿Cuál es el pasado de 'ir'?",
    respostas: {
        a: "Voy",
        b: "Iba",
        c: "Vá",
        d: "Fui",
        e: "Yendo"
    },
    respostaCorreta: "d",
    explicacao: "El pasado de 'ir' es 'fui'."
},
{
    pergunta: "¿Qué oración es gramaticalmente correcta?",
    respostas: {
        a: "Ella no gusta las manzanas.",
        b: "A él le gusta jugar al fútbol.",
        c: "Ellos fue felices.",
        d: "Yo soy ir a la tienda.",
        e: "Tú es mi amigo."
    },
    respostaCorreta: "b",
    explicacao: "La oración correcta es 'A él le gusta jugar al fútbol.'"
},
{
    pergunta: "¿Qué significa la palabra 'benevolente'?",
    respostas: {
        a: "Malvado",
        b: "Amable",
        c: "Egoísta",
        d: "Indiferente",
        e: "Codicioso"
    },
    respostaCorreta: "b",
    explicacao: "'Benevolente' significa ser amable y generoso."
},
{
    pergunta: "What is the synonym of 'happy'?",
    respostas: {
        a: "Sad",
        b: "Joyful",
        c: "Angry",
        d: "Tired",
        e: "Bored"
    },
    respostaCorreta: "b",
    explicacao: "The word 'joyful' is a synonym of 'happy'."
},
{
    pergunta: "Which of the following is a verb?",
    respostas: {
        a: "Quickly",
        b: "Run",
        c: "Beautiful",
        d: "Happiness",
        e: "Blue"
    },
    respostaCorreta: "b",
    explicacao: "'Run' is a verb that indicates an action."
},
{
    pergunta: "What is the past tense of 'go'?",
    respostas: {
        a: "Goes",
        b: "Gone",
        c: "Went",
        d: "Going",
        e: "Go"
    },
    respostaCorreta: "c",
    explicacao: "The past tense of 'go' is 'went'."
},
{
    pergunta: "Which sentence is grammatically correct?",
    respostas: {
        a: "She don't like apples.",
        b: "He likes playing football.",
        c: "They was happy.",
        d: "I am go to the store.",
        e: "You is my friend."
    },
    respostaCorreta: "b",
    explicacao: "The correct sentence is 'He likes playing football.'"
},
{
    pergunta: "What does the word 'benevolent' mean?",
    respostas: {
        a: "Evil",
        b: "Kind",
        c: "Selfish",
        d: "Indifferent",
        e: "Greedy"
    },
    respostaCorreta: "b",
    explicacao: "'Benevolent' means being kind and generous."
}//90
  ];

  const totalQuestoes = 90; 
  let indiceQuestaoAtual = 0;
  let indiceResultadoAtual = 0;
  let questoesRespondidas = new Array(totalQuestoes).fill(false);
  let respostasUsuario = new Array(totalQuestoes).fill(null);
  let tempoDecorrido = 0;
  let temporizadorIntervalo;
  let tempoDecorridoo = 0;
  let temporizadorIntervaloo;
  let temporizadorIniciadoo = false; 
  function iniciarTemporizador() {
    temporizadorIntervalo = setInterval(() => {
      tempoDecorrido++;
      const minutos = Math.floor(tempoDecorrido / 60);
      const segundos = tempoDecorrido % 60;
      document.getElementById('temporizador').innerText = `Tempo: ${minutos}:${segundos < 10 ? '0' : ''}${segundos}`;
    }, 1000);
  }

  function carregarSimulado() {
    const containerSimulado = document.getElementById('quiz');
    let conteudoSimulado = '';

    for (let i = 0; i < totalQuestoes; i++) {
      conteudoSimulado += `
        <div class="questao" id="questao${i}">
          <h4>${i + 1}. ${questoes[i % questoes.length].pergunta}</h4><br><br>
          <ul class="respostas">
            <li><input type="radio" name="questao${i}" value="a" onclick="marcarQuestao(${i})"> ${questoes[i % questoes.length].respostas.a}</li>
            <li><input type="radio" name="questao${i}" value="b" onclick="marcarQuestao(${i})"> ${questoes[i % questoes.length].respostas.b}</li>
            <li><input type="radio" name="questao${i}" value="c" onclick="marcarQuestao(${i})"> ${questoes[i % questoes.length].respostas.c}</li>
            <li><input type="radio" name="questao${i}" value="d" onclick="marcarQuestao(${i})"> ${questoes[i % questoes.length].respostas.d}</li>
            <li><input type="radio" name="questao${i}" value="e" onclick="marcarQuestao(${i})"> ${questoes[i % questoes.length].respostas.e}</li>
          </ul>
        </div>
      `;
    }

    containerSimulado.innerHTML = conteudoSimulado;
    carregarMenuQuestoes();
    mostrarQuestao(indiceQuestaoAtual);
    iniciarTemporizador();
  }

  function carregarMenuQuestoes() {
    const containerMenu = document.getElementById('menu-questoes');
    let conteudoMenu = '';

    for (let i = 0; i < totalQuestoes; i++) {
      conteudoMenu += `<div id="menu-questao${i}" class="numero-questao questao-nao-respondida" onclick="irParaQuestao(${i})">${i + 1}</div>`;
    }

    containerMenu.innerHTML = conteudoMenu;
  }

  function marcarQuestao(indice) {
    questoesRespondidas[indice] = true;
    document.getElementById(`menu-questao${indice}`).classList.remove('questao-nao-respondida');
    document.getElementById(`menu-questao${indice}`).classList.add('questao-respondida');
    respostasUsuario[indice] = document.querySelector(`input[name="questao${indice}"]:checked`).value;
    atualizarNavegacao();
  }

  function irParaQuestao(indice) {
    indiceQuestaoAtual = indice;
    mostrarQuestao(indiceQuestaoAtual);
  }

  function mostrarQuestao(indice) {
    const questaoAtiva = document.querySelector('.questao.ativa');
    if (questaoAtiva) {
      questaoAtiva.classList.remove('ativa');
    }
    document.getElementById(`questao${indice}`).classList.add('ativa');

    const botaoAnterior = document.getElementById('botao-anterior');
    const botaoSubmit = document.getElementById('botao-submit');
    const botaoProximo = document.getElementById('botao-proximo');

    botaoAnterior.classList.toggle('oculto', indice === 0);
    botaoSubmit.classList.toggle('oculto', !questoesRespondidas[indice]);
    botaoProximo.innerText = indice === totalQuestoes - 1 ? 'Ver Resultado' : 'Próximo';
  }

  function proximaQuestao() {
    if (indiceQuestaoAtual < totalQuestoes - 1) {
      indiceQuestaoAtual++;
      mostrarQuestao(indiceQuestaoAtual);
    } else {
      mostrarResultados();
    }
  }

  function questaoAnterior() {
    if (indiceQuestaoAtual > 0) {
      indiceQuestaoAtual--;
      mostrarQuestao(indiceQuestaoAtual);
    }
  }

  function mostrarResultados() {
    clearInterval(temporizadorIntervalo);
    const containerResultado = document.getElementById('container-resultado');
    const slidesResultado = document.getElementById('slides-resultado');
    slidesResultado.innerHTML = '';
    let acertos = 0;

    questoes.forEach((questao, index) => {
      const respostaSelecionada = respostasUsuario[index];
      const resultado = respostaSelecionada === questao.respostaCorreta ? 'Acertou' : 'Errou';
      const explicacao = resultado === 'Errou' ? questao.explicacao : '';
      
      if (resultado === 'Acertou') {
        acertos++;
        document.getElementById(`menu-questao${index}`).classList.add('questao-respondida');
      }

      slidesResultado.innerHTML += `
        <div class="slide-resultado ${resultado.toLowerCase() === 'acertou' ? 'acertou' : 'errou'}">
          <br><h2>${index + 1}. ${questao.pergunta}</h2>
          <p><br> ${resultado}</p>
          <p>${explicacao}</p>
        </div>
      `;
    });

    slidesResultado.innerHTML += `<br><h3>Você acertou ${acertos} de ${totalQuestoes} questões.</h3>`;
    slidesResultado.innerHTML += `<br><p>Tempo total: ${document.getElementById('temporizador').innerText.split(': ')[1]}</p>`;
    containerResultado.classList.add('ativa');
    containerResultado.style.display = 'block';
  }

  function slideAnterior() {
    const slidesResultado = document.querySelectorAll('.slide-resultado');
    slidesResultado.forEach((slide, index) => {
      slide.classList.remove('ativa');
      if (index === indiceResultadoAtual) {
        slide.classList.add('ativa');
      }
    });

    if (indiceResultadoAtual > 0) {
      indiceResultadoAtual--;
    }
  }

  function slideProximo() {
    const slidesResultado = document.querySelectorAll('.slide-resultado');
    slidesResultado.forEach((slide, index) => {
      slide.classList.remove('ativa');
      if (index === indiceResultadoAtual) {
        slide.classList.add('ativa');
      }
    });

    if (indiceResultadoAtual < slidesResultado.length - 1) {
      indiceResultadoAtual++;
    }
  }

  carregarSimulado();



