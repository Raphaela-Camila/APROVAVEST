<?php
$servername = "localhost";
$username = "root";
$password = ""; 
$dbname = "banco";

// Conectar ao banco de dados
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Verificar se os campos de formulário estão preenchidos
if (empty($_POST['email']) || empty($_POST['senha']) || empty($_POST['nome']) || empty($_POST['nasc']) || empty($_POST['cpf'])) {
    echo "<script>alert('Preencha todos os campos!');</script>";
    echo "<script>window.location.href='entrar.html';</script>";
    exit();
}

// Preparar e executar a consulta para inserir o novo usuário
$stmt = $conn->prepare("INSERT INTO usuarios (nome, nasc, cpf, email, senha) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssss", $_POST['nome'], $_POST['nasc'], $_POST['cpf'], $_POST['email'], $_POST['senha']);

if ($stmt->execute()) {
    echo "<script>alert('Cadastro realizado com sucesso!');</script>";
    echo "<script>window.location.href='entrar.html';</script>";
} else {
    echo "<script>alert('Erro ao cadastrar o usuário');</script>";
    echo "<script>window.location.href='entrar.html';</script>";
}

$stmt->close();
$conn->close();
?>