const questoes = [
    {
      pergunta: "Para serem absorvidos pelas células do intestino humano, os lipídios ingeridos precisam ser primeiramente emulsificados. Nessa etapa da digestão, torna-se necessária a ação dos ácidos biliares, visto que os lipídios apresentam uma natureza apoiar e são insolúveis em água. Esses ácidos atuam no processo de modo a",
      respostas: {
        a: "hidrolisar os lipídios.",
        b: "agir como detergentes.",
        c: "tornar os lipídios anfifílicos.",
        d: "promover a secreção de lipases.",
        e: "estimular o trânsito intestinal dos lipídios."
      },
      respostaCorreta: "b",
      explicacao: "Durante a digestão temos a liberação da bile, produzida no fígado e liberada pela vesícula biliar, na região do duodeno. A função dela é de emulsificar a gordura, ou seja, atuar como um “detergente”, aumentando a superfície de contato e facilitando a atuação das enzimas lipases."
    },
    {
        pergunta: "Um imóvel foi comprado por R$ 200.000,00 e valorizou-se 20% ao longo de um ano. Qual é o novo valor do imóvel?",
        respostas: {
            a: "R$ 220.000,00",
            b: "R$ 240.000,00",
            c: "R$ 250.000,00",
            d: "R$ 260.000,00",
            e: "R$ 280.000,00"
        },
        respostaCorreta: "b",
        explicacao: "O valor do imóvel após a valorização é R$ 200.000,00 + (20% de R$ 200.000,00) = R$ 200.000,00 + R$ 40.000,00 = R$ 240.000,00."
    },
    {
        pergunta: "Qual é a solução da equação 3(x - 4) = 21?",
        respostas: {
            a: "x = 4",
            b: "x = 7",
            c: "x = 11",
            d: "x = 17",
            e: "x = 21"
        },
        respostaCorreta: "c",
        explicacao: "Resolvendo: 3(x - 4) = 21; x - 4 = 7; x = 11."
    },
    {
        pergunta: "Um tanque de água tem a forma de um paralelepípedo retângulo com 2 m de comprimento, 1 m de largura e 1,5 m de altura. Qual é o volume do tanque?",
        respostas: {
            a: "3 m³",
            b: "2 m³",
            c: "2,5 m³",
            d: "1,5 m³",
            e: "1 m³"
        },
        respostaCorreta: "a",
        explicacao: "O volume é dado por V = comprimento × largura × altura = 2 × 1 × 1,5 = 3 m³."
    },
    {
        pergunta: "Se 5x + 2 = 27, qual é o valor de x?",
        respostas: {
            a: "5",
            b: "4",
            c: "3",
            d: "2",
            e: "1"
        },
        respostaCorreta: "b",
        explicacao: "Resolvendo: 5x = 27 - 2; 5x = 25; x = 25 / 5 = 5."
    },
    {
        pergunta: "Qual é o próximo número na sequência: 2, 4, 8, 16, ...?",
        respostas: {
            a: "20",
            b: "24",
            c: "32",
            d: "36",
            e: "40"
        },
        respostaCorreta: "c",
        explicacao: "A sequência é uma progressão geométrica em que cada número é o dobro do anterior."
    },
    {
        pergunta: "Qual é a expressão que representa a soma dos ângulos internos de um hexágono?",
        respostas: {
            a: "360°",
            b: "540°",
            c: "720°",
            d: "900°",
            e: "1080°"
        },
        respostaCorreta: "b",
        explicacao: "A soma dos ângulos internos de um polígono é dada por (n - 2) × 180°, onde n é o número de lados. Para um hexágono (n=6): (6 - 2) × 180° = 4 × 180° = 720°."
    },
    {
        pergunta: "Um investimento de R$ 1.000,00 a uma taxa de juros simples de 5% ao ano, por 3 anos, gera um montante de:",
        respostas: {
            a: "R$ 1.150,00",
            b: "R$ 1.200,00",
            c: "R$ 1.250,00",
            d: "R$ 1.300,00",
            e: "R$ 1.350,00"
        },
        respostaCorreta: "c",
        explicacao: "O montante é dado por M = P + J, onde J = P × i × t. Assim, M = 1.000 + (1.000 × 0,05 × 3) = 1.000 + 150 = R$ 1.150,00."
    },
    {
        pergunta: "Qual é a solução da inequação 2x - 3 > 7?",
        respostas: {
            a: "x > 5",
            b: "x > 4",
            c: "x < 4",
            d: "x < 5",
            e: "x = 4"
        },
        respostaCorreta: "a",
        explicacao: "Resolvendo: 2x > 10; x > 5."
    },
    {
        pergunta: "Qual é o perímetro de um quadrado cuja aresta mede 6 cm?",
        respostas: {
            a: "18 cm",
            b: "24 cm",
            c: "30 cm",
            d: "36 cm",
            e: "42 cm"
        },
        respostaCorreta: "b",
        explicacao: "O perímetro do quadrado é dado por P = 4 × a, onde a é a aresta: P = 4 × 6 = 24 cm."
    },//10
    {
        pergunta: "Qual é a probabilidade de tirar um número par de um dado comum (de 1 a 6)?",
        respostas: {
            a: "1/2",
            b: "1/3",
            c: "1/4",
            d: "1/6",
            e: "1/5"
        },
        respostaCorreta: "a",
        explicacao: "Os números pares são 2, 4 e 6. Então, a probabilidade é 3 números pares / 6 números totais = 1/2."
    },
    {
        pergunta: "Um carro percorre 150 km em 2 horas. Qual é a sua velocidade média?",
        respostas: {
            a: "60 km/h",
            b: "75 km/h",
            c: "100 km/h",
            d: "120 km/h",
            e: "150 km/h"
        },
        respostaCorreta: "b",
        explicacao: "A velocidade média é calculada dividindo a distância pelo tempo: 150 km / 2 h = 75 km/h."
    },
    {
        pergunta: "Qual é o valor de x na equação 2x + 3 = 11?",
        respostas: {
            a: "2",
            b: "3",
            c: "4",
            d: "5",
            e: "6"
        },
        respostaCorreta: "4",
        explicacao: "Resolvendo a equação, temos 2x = 11 - 3, então 2x = 8, x = 8/2 = 4."
    },
    {
        pergunta: "Qual é o resultado de 7^2 + 4 × 3?",
        respostas: {
            a: "49",
            b: "55",
            c: "61",
            d: "70",
            e: "77"
        },
        respostaCorreta: "61",
        explicacao: "Calculando: 7^2 = 49 e 4 × 3 = 12. Então 49 + 12 = 61."
    },
    {
        pergunta: "Uma caixa d'água tem a forma de um cilindro com raio de 1 m e altura de 3 m. Qual é o volume da caixa d'água?",
        respostas: {
            a: "3π m³",
            b: "π m³",
            c: "2π m³",
            d: "4π m³",
            e: "5π m³"
        },
        respostaCorreta: "3π m³",
        explicacao: "O volume do cilindro é dado por V = πr²h, onde r = 1 m e h = 3 m: V = π(1²)(3) = 3π m³."
    },
    {
        pergunta: "Qual é a soma dos ângulos internos de um triângulo?",
        respostas: {
            a: "90°",
            b: "180°",
            c: "270°",
            d: "360°",
            e: "540°"
        },
        respostaCorreta: "b",
        explicacao: "A soma dos ângulos internos de um triângulo é sempre 180°."
    },
    {
        pergunta: "Qual é a raiz quadrada de 144?",
        respostas: {
            a: "10",
            b: "11",
            c: "12",
            d: "13",
            e: "14"
        },
        respostaCorreta: "c",
        explicacao: "A raiz quadrada de 144 é 12."
    },
    {
        pergunta: "Se um ângulo é reto, qual é o seu valor em graus?",
        respostas: {
            a: "45°",
            b: "90°",
            c: "120°",
            d: "180°",
            e: "360°"
        },
        respostaCorreta: "b",
        explicacao: "Um ângulo reto mede 90°."
    },
    {
        pergunta: "Qual é a função do segundo grau que possui as raízes x = 2 e x = -3?",
        respostas: {
            a: "f(x) = (x - 2)(x + 3)",
            b: "f(x) = (x + 2)(x - 3)",
            c: "f(x) = (x - 2)(x - 3)",
            d: "f(x) = (x + 3)(x + 2)",
            e: "f(x) = (x - 3)(x + 3)"
        },
        respostaCorreta: "a",
        explicacao: "A função é dada por f(x) = (x - 2)(x + 3)."
    },
    {
        pergunta: "Se um triângulo tem lados medindo 5 cm, 12 cm e 13 cm, ele é:",
        respostas: {
            a: "Equilátero",
            b: "Isósceles",
            c: "Escaleno",
            d: "Retângulo",
            e: "Obtusângulo"
        },
        respostaCorreta: "d",
        explicacao: "O triângulo é retângulo, pois 5² + 12² = 13²."
    },//20
    {
        pergunta: "Qual é o resultado de 2 + 3 × 4?",
        respostas: {
            a: "14",
            b: "20",
            c: "24",
            d: "26",
            e: "30"
        },
        respostaCorreta: "14",
        explicacao: "Pela ordem das operações, 3 × 4 = 12, então 2 + 12 = 14."
    },
    {
        pergunta: "Qual é a equação da reta que passa pelos pontos (1, 2) e (3, 4)?",
        respostas: {
            a: "y = x + 1",
            b: "y = 2x + 1",
            c: "y = x + 2",
            d: "y = 2x + 2",
            e: "y = 3x - 1"
        },
        respostaCorreta: "a",
        explicacao: "A equação da reta é dada pela fórmula da forma y = mx + b. O coeficiente angular m é 1, portanto y = x + 1."
    },
    {
        pergunta: "Qual é a velocidade em km/h de um ciclista que percorre 12 km em 30 minutos?",
        respostas: {
            a: "24 km/h",
            b: "36 km/h",
            c: "48 km/h",
            d: "60 km/h",
            e: "72 km/h"
        },
        respostaCorreta: "b",
        explicacao: "30 minutos é 0,5 horas, então a velocidade é 12 km / 0,5 h = 24 km/h."
    },
    {
        pergunta: "Se uma função é definida por f(x) = 3x + 2, qual é o valor de f(4)?",
        respostas: {
            a: "10",
            b: "12",
            c: "14",
            d: "16",
            e: "18"
        },
        respostaCorreta: "b",
        explicacao: "Substituindo x por 4, f(4) = 3(4) + 2 = 12 + 2 = 14."
    },
    {
        pergunta: "Qual é a distância entre os pontos (2, 3) e (5, 7)?",
        respostas: {
            a: "5",
            b: "7",
            c: "8",
            d: "10",
            e: "12"
        },
        respostaCorreta: "d",
        explicacao: "A distância é dada pela fórmula d = √[(x2 - x1)² + (y2 - y1)²] = √[(5 - 2)² + (7 - 3)²] = √(9 + 16) = √25 = 5."
    },
    {
        pergunta: "Um recipiente tem a forma de um cubo com aresta de 4 cm. Qual é o volume do recipiente?",
        respostas: {
            a: "8 cm³",
            b: "16 cm³",
            c: "24 cm³",
            d: "32 cm³",
            e: "64 cm³"
        },
        respostaCorreta: "e",
        explicacao: "O volume do cubo é dado por V = a³, onde a é a aresta: V = 4³ = 64 cm³."
    },
    {
        pergunta: "Qual é o gráfico da função y = x²?",
        respostas: {
            a: "Reta",
            b: "Parábola",
            c: "Círculo",
            d: "Hipérbole",
            e: "Elipse"
        },
        respostaCorreta: "b",
        explicacao: "O gráfico da função quadrática y = x² é uma parábola."
    },
    {
        pergunta: "Qual é a média aritmética dos números 3, 7 e 9?",
        respostas: {
            a: "6",
            b: "7",
            c: "8",
            d: "9",
            e: "10"
        },
        respostaCorreta: "b",
        explicacao: "A média é (3 + 7 + 9) / 3 = 19 / 3 = 6,33."
    },
    {
        pergunta: "Qual é a fórmula para calcular a área de um triângulo?",
        respostas: {
            a: "A = b × h",
            b: "A = b × h / 2",
            c: "A = b + h",
            d: "A = b²",
            e: "A = 2 × b × h"
        },
        respostaCorreta: "b",
        explicacao: "A área do triângulo é dada por A = (b × h) / 2."
    },
    {
        pergunta: "Se um ângulo mede 120°, qual é o seu complemento?",
        respostas: {
            a: "60°",
            b: "30°",
            c: "90°",
            d: "180°",
            e: "150°"
        },
        respostaCorreta: "a",
        explicacao: "O complemento de um ângulo é 90° menos o ângulo, então 90° - 120° = -30°."
    },//30
    {
        pergunta: "Qual é a fórmula química da água?",
        respostas: {
            a: "H2O",
            b: "CO2",
            c: "O2",
            d: "NaCl",
            e: "C6H12O6"
        },
        respostaCorreta: "a",
        explicacao: "A água é composta por dois átomos de hidrogênio e um átomo de oxigênio, representada pela fórmula H2O."
    },
    {
        pergunta: "Em uma célula animal, qual organela é responsável pela produção de energia?",
        respostas: {
            a: "Ribossomo",
            b: "Mitocôndria",
            c: "Lisossomo",
            d: "Cloroplasto",
            e: "Retículo endoplasmático"
        },
        respostaCorreta: "b",
        explicacao: "As mitocôndrias são conhecidas como as 'usinas de energia' da célula, onde ocorre a respiração celular."
    },
    {
        pergunta: "Qual é o principal gás responsável pelo efeito estufa?",
        respostas: {
            a: "Oxigênio",
            b: "Dióxido de carbono",
            c: "Nitrogênio",
            d: "Metano",
            e: "Hélio"
        },
        respostaCorreta: "b",
        explicacao: "O dióxido de carbono (CO2) é um dos principais gases que contribuem para o efeito estufa, retendo calor na atmosfera."
    },
    {
        pergunta: "Qual é o processo pelo qual as plantas convertem luz solar em energia química?",
        respostas: {
            a: "Respiração celular",
            b: "Fotossíntese",
            c: "Fermentação",
            d: "Quimiossíntese",
            e: "Transpiração"
        },
        respostaCorreta: "b",
        explicacao: "A fotossíntese é o processo em que as plantas usam a luz solar para converter dióxido de carbono e água em glicose e oxigênio."
    },
    {
        pergunta: "Qual é a fórmula para calcular a área de um círculo?",
        respostas: {
            a: "A = 2πr",
            b: "A = πr²",
            c: "A = r²",
            d: "A = 2r",
            e: "A = πd"
        },
        respostaCorreta: "b",
        explicacao: "A área de um círculo é calculada pela fórmula A = πr², onde r é o raio."
    },
    {
        pergunta: "Qual é a unidade de medida da pressão no Sistema Internacional (SI)?",
        respostas: {
            a: "Pascal (Pa)",
            b: "Newton (N)",
            c: "Joule (J)",
            d: "Bar",
            e: "Atmosfera (atm)"
        },
        respostaCorreta: "a",
        explicacao: "A unidade de pressão no Sistema Internacional é o Pascal (Pa), que é equivalente a um Newton por metro quadrado."
    },
    {
        pergunta: "Qual é a principal função do sistema circulatório humano?",
        respostas: {
            a: "Produzir hormônios",
            b: "Transportar nutrientes e oxigênio",
            c: "Proteger o corpo contra infecções",
            d: "Regular a temperatura corporal",
            e: "Realizar a digestão"
        },
        respostaCorreta: "b",
        explicacao: "O sistema circulatório é responsável por transportar nutrientes e oxigênio para as células do corpo."
    },
    {
        pergunta: "O que é um organismo autotrófico?",
        respostas: {
            a: "Um organismo que se alimenta de outros organismos",
            b: "Um organismo que produz seu próprio alimento",
            c: "Um organismo que vive em simbiose",
            d: "Um organismo que se reproduz assexuadamente",
            e: "Um organismo que não possui células"
        },
        respostaCorreta: "b",
        explicacao: "Os organismos autotróficos, como as plantas, produzem seu próprio alimento através da fotossíntese."
    },
    {
        pergunta: "Qual é o princípio que descreve a conservação da energia em um sistema isolado?",
        respostas: {
            a: "Princípio de Heisenberg",
            b: "Princípio de Pascal",
            c: "Princípio da Incerteza",
            d: "Princípio da Conservação da Energia",
            e: "Princípio de Arquimedes"
        },
        respostaCorreta: "d",
        explicacao: "O princípio da conservação da energia afirma que a energia não pode ser criada nem destruída, apenas transformada."
    },
    {
        pergunta: "Qual é a função do DNA nas células?",
        respostas: {
            a: "Produzir energia",
            b: "Armazenar informações genéticas",
            c: "Transportar nutrientes",
            d: "Regular a temperatura",
            e: "Destruir células doentes"
        },
        respostaCorreta: "b",
        explicacao: "O DNA armazena as informações genéticas que determinam as características de um organismo."
    },//40
    {
        pergunta: "Qual é a velocidade da luz no vácuo?",
        respostas: {
            a: "300.000 km/s",
            b: "150.000 km/s",
            c: "1.000 km/s",
            d: "600.000 km/s",
            e: "450.000 km/s"
        },
        respostaCorreta: "a",
        explicacao: "A velocidade da luz no vácuo é aproximadamente 300.000 km/s."
    },
    {
        pergunta: "Em um triângulo retângulo, a soma dos ângulos internos é igual a:",
        respostas: {
            a: "90°",
            b: "180°",
            c: "360°",
            d: "270°",
            e: "45°"
        },
        respostaCorreta: "b",
        explicacao: "A soma dos ângulos internos de qualquer triângulo, incluindo o triângulo retângulo, é sempre 180°."
    },
    {
        pergunta: "Qual é a fórmula da lei de Hooke para a elasticidade?",
        respostas: {
            a: "F = ma",
            b: "F = kx",
            c: "F = mg",
            d: "F = v/t",
            e: "F = pV"
        },
        respostaCorreta: "b",
        explicacao: "A lei de Hooke afirma que a força (F) exercida por uma mola é proporcional à extensão (x) da mola, com k sendo a constante elástica."
    },
    {
        pergunta: "Qual é a principal função dos ribossomos na célula?",
        respostas: {
            a: "Produzir energia",
            b: "Sintetizar proteínas",
            c: "Armazenar glicose",
            d: "Transportar oxigênio",
            e: "Proteger contra vírus"
        },
        respostaCorreta: "b",
        explicacao: "Os ribossomos são responsáveis pela síntese de proteínas, traduzindo a informação genética do RNA."
    },
    {
        pergunta: "Qual é a principal fonte de energia para os seres vivos?",
        respostas: {
            a: "Carboidratos",
            b: "Proteínas",
            c: "Lipídios",
            d: "Água",
            e: "Vitaminas"
        },
        respostaCorreta: "a",
        explicacao: "Os carboidratos são a principal fonte de energia para os seres vivos, sendo rapidamente metabolizados."
    },
    {
        pergunta: "Qual é a fórmula química do cloreto de sódio?",
        respostas: {
            a: "NaCl",
            b: "KCl",
            c: "CaCl2",
            d: "MgCl2",
            e: "Na2SO4"
        },
        respostaCorreta: "a",
        explicacao: "O cloreto de sódio, conhecido como sal de cozinha, é formado pela combinação de sódio (Na) e cloro (Cl), resultando na fórmula NaCl."
    },
    {
        pergunta: "O que é a biodiversidade?",
        respostas: {
            a: "A quantidade de organismos de uma espécie",
            b: "A variedade de espécies em um ecossistema",
            c: "A reprodução assexuada das plantas",
            d: "A extinção de espécies",
            e: "A temperatura média de um bioma"
        },
        respostaCorreta: "b",
        explicacao: "Biodiversidade refere-se à variedade de espécies e organismos em um determinado ecossistema."
    },
    {
        pergunta: "Qual é a principal função dos vasos sanguíneos?",
        respostas: {
            a: "Armazenar sangue",
            b: "Transportar oxigênio e nutrientes",
            c: "Proteger contra infecções",
            d: "Produzir hormônios",
            e: "Realizar a digestão"
        },
        respostaCorreta: "b",
        explicacao: "Os vasos sanguíneos são responsáveis por transportar oxigênio e nutrientes para as células e remover resíduos."
    },
    {
        pergunta: "Qual é o principal elemento químico encontrado nos seres vivos?",
        respostas: {
            a: "Carbono",
            b: "Oxigênio",
            c: "Nitrogênio",
            d: "Hidrogênio",
            e: "Fósforo"
        },
        respostaCorreta: "a",
        explicacao: "O carbono é o principal elemento químico encontrado em todas as biomoléculas que constituem os seres vivos."
    },//50
    {
        pergunta: "Qual é a fórmula da reação de neutralização entre um ácido e uma base?",
        respostas: {
            a: "Ácido + Base → Sal + Água",
            b: "Ácido + Água → Base",
            c: "Base + Água → Ácido",
            d: "Sal + Água → Ácido + Base",
            e: "Ácido + Sal → Base"
        },
        respostaCorreta: "a",
        explicacao: "Na reação de neutralização, um ácido reage com uma base para formar um sal e água."
    },//50
    {
        pergunta: "Qual é o princípio que afirma que a pressão exercida por um gás é inversamente proporcional ao seu volume, mantendo a temperatura constante?",
        respostas: {
            a: "Lei de Charles",
            b: "Lei de Boyle",
            c: "Lei de Avogadro",
            d: "Lei de Gay-Lussac",
            e: "Lei de Dalton"
        },
        respostaCorreta: "b",
        explicacao: "A Lei de Boyle estabelece que a pressão de um gás é inversamente proporcional ao seu volume, se a temperatura for constante."
    },
    {
        pergunta: "Qual é a principal característica dos sólidos em relação às partículas?",
        respostas: {
            a: "As partículas estão em movimento livre",
            b: "As partículas estão muito distantes umas das outras",
            c: "As partículas estão dispostas em uma estrutura fixa",
            d: "As partículas não têm atração entre si",
            e: "As partículas se movem rapidamente"
        },
        respostaCorreta: "c",
        explicacao: "Nos sólidos, as partículas estão organizadas em uma estrutura fixa, resultando em forma e volume definidos."
    },
    {
        pergunta: "Qual é a unidade de medida da força no Sistema Internacional (SI)?",
        respostas: {
            a: "Newton (N)",
            b: "Joule (J)",
            c: "Pascal (Pa)",
            d: "Kilograma (kg)",
            e: "Watts (W)"
        },
        respostaCorreta: "a",
        explicacao: "A unidade de medida da força no Sistema Internacional é o Newton (N)."
    },
    {
        pergunta: "Qual é o principal ácido presente no suco gástrico do estômago humano?",
        respostas: {
            a: "Ácido acético",
            b: "Ácido clorídrico",
            c: "Ácido sulfúrico",
            d: "Ácido cítrico",
            e: "Ácido fosfórico"
        },
        respostaCorreta: "b",
        explicacao: "O ácido clorídrico (HCl) é o principal ácido presente no suco gástrico, ajudando na digestão."
    },
    {
        pergunta: "O que é a energia cinética?",
        respostas: {
            a: "Energia armazenada em um objeto",
            b: "Energia associada ao movimento de um objeto",
            c: "Energia gerada por reações químicas",
            d: "Energia liberada na forma de calor",
            e: "Energia proveniente da eletricidade"
        },
        respostaCorreta: "b",
        explicacao: "A energia cinética é a energia que um objeto possui devido ao seu movimento."
    },
    {
        pergunta: "Qual é a reação química que ocorre quando um combustível queima na presença de oxigênio?",
        respostas: {
            a: "Combustão",
            b: "Fermentação",
            c: "Oxidação",
            d: "Redução",
            e: "Sublimação"
        },
        respostaCorreta: "a",
        explicacao: "A combustão é uma reação química que ocorre quando um combustível reage com oxigênio, liberando calor e luz."
    },
    {
        pergunta: "Qual é o princípio que estabelece que a energia total em um sistema isolado permanece constante?",
        respostas: {
            a: "Princípio da Incerteza",
            b: "Princípio da Conservação da Energia",
            c: "Princípio de Pascal",
            d: "Princípio de Arquimedes",
            e: "Princípio de Heisenberg"
        },
        respostaCorreta: "b",
        explicacao: "O princípio da conservação da energia afirma que a energia total de um sistema isolado permanece constante ao longo do tempo."
    },
    {
        pergunta: "O que é a eletroquímica?",
        respostas: {
            a: "Estudo da relação entre eletricidade e reações químicas",
            b: "Estudo das propriedades dos sólidos",
            c: "Estudo das reações de combustão",
            d: "Estudo do movimento dos corpos",
            e: "Estudo das ligações químicas"
        },
        respostaCorreta: "a",
        explicacao: "A eletroquímica é o ramo da química que estuda a relação entre eletricidade e reações químicas."
    },
    {
        pergunta: "Qual é a fórmula da aceleração?",
        respostas: {
            a: "a = v/t",
            b: "a = m/f",
            c: "a = f/m",
            d: "a = d/t²",
            e: "a = v²/t"
        },
        respostaCorreta: "c",
        explicacao: "A aceleração (a) é calculada pela fórmula a = f/m, onde f é a força e m é a massa do objeto."
    },
    {
        pergunta: "Qual é a função do catalisador em uma reação química?",
        respostas: {
            a: "Aumentar a temperatura da reação",
            b: "Acelerar a reação sem ser consumido",
            c: "Diminuir a pressão da reação",
            d: "Alterar a estequiometria da reação",
            e: "Inibir a reação"
        },
        respostaCorreta: "b",
        explicacao: "Um catalisador acelera uma reação química sem ser consumido, permitindo que a reação ocorra mais rapidamente."
    },//60
    {
        pergunta: "Qual é o valor de π (pi) com duas casas decimais?",
        respostas: {
            a: "3.12",
            b: "3.14",
            c: "3.16",
            d: "3.18",
            e: "3.20"
        },
        respostaCorreta: "b",
        explicacao: "O valor de π (pi) é aproximadamente 3.14."
    },
    {
        pergunta: "Qual é a fórmula do Teorema de Pitágoras?",
        respostas: {
            a: "a² + b² = c",
            b: "a² + b² = c²",
            c: "a + b = c",
            d: "c² = a + b",
            e: "c² = a - b"
        },
        respostaCorreta: "b",
        explicacao: "O Teorema de Pitágoras afirma que, em um triângulo retângulo, a soma dos quadrados dos catetos é igual ao quadrado da hipotenusa: a² + b² = c²."
    },
    {
        pergunta: "Se um carro percorre 120 km em 2 horas, qual é sua velocidade média?",
        respostas: {
            a: "50 km/h",
            b: "60 km/h",
            c: "70 km/h",
            d: "80 km/h",
            e: "90 km/h"
        },
        respostaCorreta: "b",
        explicacao: "A velocidade média é calculada como distância dividida pelo tempo: 120 km / 2 h = 60 km/h."
    },
    {
        pergunta: "Qual é a fórmula da energia cinética (Ec) de um corpo em movimento?",
        respostas: {
            a: "Ec = mv",
            b: "Ec = mv²",
            c: "Ec = mgh",
            d: "Ec = 1/2 mv²",
            e: "Ec = 1/2 mv"
        },
        respostaCorreta: "d",
        explicacao: "A energia cinética é dada pela fórmula Ec = 1/2 mv², onde m é a massa e v é a velocidade."
    },
    {
        pergunta: "Qual é a unidade de medida da pressão no Sistema Internacional (SI)?",
        respostas: {
            a: "Pascal (Pa)",
            b: "Newton (N)",
            c: "Joule (J)",
            d: "Atmosfera (atm)",
            e: "Bar"
        },
        respostaCorreta: "a",
        explicacao: "A unidade de medida da pressão no Sistema Internacional é o Pascal (Pa)."
    },
    {
        pergunta: "Qual é o principal gás que causa o efeito estufa?",
        respostas: {
            a: "Dióxido de carbono (CO₂)",
            b: "Oxigênio (O₂)",
            c: "Nitrogênio (N₂)",
            d: "Metano (CH₄)",
            e: "Hélio (He)"
        },
        respostaCorreta: "a",
        explicacao: "O dióxido de carbono (CO₂) é um dos principais gases que contribuem para o efeito estufa."
    },
    {
        pergunta: "Em um triângulo retângulo, qual é a soma dos ângulos internos?",
        respostas: {
            a: "90°",
            b: "180°",
            c: "270°",
            d: "360°",
            e: "450°"
        },
        respostaCorreta: "b",
        explicacao: "A soma dos ângulos internos de qualquer triângulo é sempre 180°."
    },
    {
        pergunta: "Qual é a fórmula da Lei de Hooke?",
        respostas: {
            a: "F = ma",
            b: "F = kx",
            c: "F = mg",
            d: "F = mv",
            e: "F = mgh"
        },
        respostaCorreta: "b",
        explicacao: "A Lei de Hooke afirma que a força (F) aplicada a uma mola é proporcional à deformação (x) da mola, ou seja, F = kx, onde k é a constante da mola."
    },
    {
        pergunta: "Qual é a equação da reta na forma geral?",
        respostas: {
            a: "y = mx + b",
            b: "y = ax² + bx + c",
            c: "Ax + By + C = 0",
            d: "y = a + bx",
            e: "x² + y² = r²"
        },
        respostaCorreta: "c",
        explicacao: "A equação da reta na forma geral é dada por Ax + By + C = 0."
    },
    {
        pergunta: "Qual é o pH de uma solução ácida?",
        respostas: {
            a: "pH < 7",
            b: "pH = 7",
            c: "pH > 7",
            d: "pH = 14",
            e: "pH = 0"
        },
        respostaCorreta: "a",
        explicacao: "Soluções ácidas têm pH menor que 7."
    },
    {
        pergunta: "Qual é a fórmula da diluição em química?",
        respostas: {
            a: "C₁V₁ = C₂V₂",
            b: "C = m/V",
            c: "P = F/A",
            d: "V = d/t",
            e: "D = m/V"
        },
        respostaCorreta: "a",
        explicacao: "A fórmula da diluição é C₁V₁ = C₂V₂, onde C é a concentração e V é o volume."
    },
    {
        pergunta: "Qual é a unidade de medida da massa no Sistema Internacional (SI)?",
        respostas: {
            a: "Newton (N)",
            b: "Kilograma (kg)",
            c: "Grama (g)",
            d: "Litro (L)",
            e: "Joule (J)"
        },
        respostaCorreta: "b",
        explicacao: "A unidade de medida da massa no Sistema Internacional é o Kilograma (kg)."
    },
    {
        pergunta: "O que representa o vetor aceleração?",
        respostas: {
            a: "Mudança de velocidade por unidade de tempo",
            b: "Mudança de direção",
            c: "Velocidade em um determinado instante",
            d: "Força aplicada em um objeto",
            e: "Energia potencial"
        },
        respostaCorreta: "a",
        explicacao: "A aceleração representa a mudança de velocidade de um objeto em um intervalo de tempo."
    },
    {
        pergunta: "Qual é a reação de combustão completa do metano (CH₄)?",
        respostas: {
            a: "CH₄ + O₂ → CO + H₂O",
            b: "CH₄ + O₂ → CO₂ + H₂O",
            c: "CH₄ + H₂O → CO + H₂",
            d: "CH₄ + CO₂ → H₂ + O₂",
            e: "CH₄ + N₂ → NH₃ + H₂O"
        },
        respostaCorreta: "b",
        explicacao: "A combustão completa do metano (CH₄) na presença de oxigênio (O₂) resulta em dióxido de carbono (CO₂) e água (H₂O)."
    },
    {
        pergunta: "O que é um número primo?",
        respostas: {
            a: "Um número que é divisível por 2",
            b: "Um número que tem exatamente dois divisores: 1 e ele mesmo",
            c: "Um número que pode ser escrito como a soma de dois quadrados",
            d: "Um número que termina em 0 ou 5",
            e: "Um número que é um quadrado perfeito"
        },
        respostaCorreta: "b",
        explicacao: "Um número primo é aquele que tem exatamente dois divisores: 1 e ele mesmo."
    },
    {
        pergunta: "Qual é a constante de Avogadro?",
        respostas: {
            a: "6.022 x 10²³ moléculas/mol",
            b: "3.1415",
            c: "9.81 m/s²",
            d: "1.602 x 10⁻¹⁹ C",
            e: "2.998 x 10⁸ m/s"
        },
        respostaCorreta: "a",
        explicacao: "A constante de Avogadro é 6.022 x 10²³ moléculas/mol, que representa o número de partículas em um mol de substância."
    },
    {
        pergunta: "Qual é a lei que relaciona a pressão e o volume de um gás mantendo a temperatura constante?",
        respostas: {
            a: "Lei de Charles",
            b: "Lei de Boyle",
            c: "Lei de Avogadro",
            d: "Lei de Gay-Lussac",
            e: "Lei de Dalton"
        },
        respostaCorreta: "b",
        explicacao: "A Lei de Boyle estabelece que, para um gás em temperatura constante, a pressão é inversamente proporcional ao volume."
    },
    {
        pergunta: "Qual é o valor aproximado de √64?",
        respostas: {
            a: "6",
            b: "7",
            c: "8",
            d: "9",
            e: "10"
        },
        respostaCorreta: "c",
        explicacao: "O valor de √64 é 8."
    },
    {
        pergunta: "Qual é o princípio da conservação da energia?",
        respostas: {
            a: "A energia não pode ser criada nem destruída, apenas transformada",
            b: "A energia total de um sistema sempre aumenta",
            c: "A energia pode ser criada a partir do nada",
            d: "A energia é sempre perdida como calor",
            e: "A energia pode ser armazenada indefinidamente"
        },
        respostaCorreta: "a",
        explicacao: "O princípio da conservação da energia afirma que a energia total em um sistema isolado permanece constante ao longo do tempo."
    }, //80
    {
        pergunta: "Qual é o resultado da expressão 5 + 7 × 2?",
        respostas: {
            a: "19",
            b: "24",
            c: "19",
            d: "12",
            e: "16"
        },
        respostaCorreta: "c",
        explicacao: "De acordo com a ordem das operações, primeiro multiplicamos e depois somamos: 5 + (7 × 2) = 5 + 14 = 19."
    },
    {
        pergunta: "Qual é a raiz quadrada de 144?",
        respostas: {
            a: "10",
            b: "12",
            c: "14",
            d: "16",
            e: "18"
        },
        respostaCorreta: "b",
        explicacao: "A raiz quadrada de 144 é 12."
    },
    {
        pergunta: "Se um triângulo tem um ângulo de 90 graus e os outros dois ângulos são iguais, quais são os valores desses ângulos?",
        respostas: {
            a: "45° cada",
            b: "30° cada",
            c: "60° cada",
            d: "90° cada",
            e: "75° cada"
        },
        respostaCorreta: "a",
        explicacao: "Em um triângulo, a soma dos ângulos internos é 180°. Se um ângulo é 90°, os outros dois ângulos devem ser iguais a 45° cada."
    },
    {
        pergunta: "Qual é o perímetro de um quadrado com lados de 4 cm?",
        respostas: {
            a: "8 cm",
            b: "12 cm",
            c: "16 cm",
            d: "20 cm",
            e: "24 cm"
        },
        respostaCorreta: "c",
        explicacao: "O perímetro de um quadrado é dado por P = 4 × lado. Portanto, P = 4 × 4 cm = 16 cm."
    },
    {
        pergunta: "Qual é a área de um círculo com raio de 3 cm?",
        respostas: {
            a: "9π cm²",
            b: "6π cm²",
            c: "12π cm²",
            d: "3π cm²",
            e: "18π cm²"
        },
        respostaCorreta: "a",
        explicacao: "A área de um círculo é dada por A = πr². Portanto, A = π(3 cm)² = 9π cm²."
    },
    {
        pergunta: "Quantos graus existem em um ângulo reto?",
        respostas: {
            a: "90°",
            b: "180°",
            c: "270°",
            d: "360°",
            e: "45°"
        },
        respostaCorreta: "a",
        explicacao: "Um ângulo reto mede exatamente 90°."
    },
    {
        pergunta: "Qual é o resultado de 10% de 250?",
        respostas: {
            a: "25",
            b: "50",
            c: "75",
            d: "100",
            e: "150"
        },
        respostaCorreta: "a",
        explicacao: "10% de 250 é calculado como 250 × 0,10 = 25."
    },
    {
        pergunta: "Qual é a equação da reta que passa pelos pontos (2, 3) e (4, 7)?",
        respostas: {
            a: "y = 2x + 1",
            b: "y = 2x - 1",
            c: "y = 3x - 3",
            d: "y = 3x + 3",
            e: "y = x + 1"
        },
        respostaCorreta: "a",
        explicacao: "A inclinação (m) da reta é (7 - 3) / (4 - 2) = 2. Usando a forma ponto-inclinação, temos y - 3 = 2(x - 2), que simplifica para y = 2x + 1."
    },
    {
        pergunta: "Se um número é triplicado e depois subtraído 5, o resultado é 16. Qual é o número?",
        respostas: {
            a: "7",
            b: "8",
            c: "9",
            d: "10",
            e: "11"
        },
        respostaCorreta: "b",
        explicacao: "Seja x o número. Então, 3x - 5 = 16. Resolvendo: 3x = 21, logo x = 7."
    },
    {
        pergunta: "Qual é a fórmula para calcular a soma dos ângulos internos de um polígono com n lados?",
        respostas: {
            a: "(n - 2) × 180°",
            b: "n × 180°",
            c: "(n + 2) × 180°",
            d: "(n - 1) × 180°",
            e: "n × 360°"
        },
        respostaCorreta: "a",
        explicacao: "A soma dos ângulos internos de um polígono é dada pela fórmula (n - 2) × 180°, onde n é o número de lados."
    }//90
  ];

  const totalQuestoes = 90; 
  let indiceQuestaoAtual = 0;
  let indiceResultadoAtual = 0;
  let questoesRespondidas = new Array(totalQuestoes).fill(false);
  let respostasUsuario = new Array(totalQuestoes).fill(null);
  let tempoDecorrido = 0;
  let temporizadorIntervalo;
  let tempoDecorridoo = 0;
  let temporizadorIntervaloo;
  let temporizadorIniciadoo = false; 
  function iniciarTemporizador() {
    temporizadorIntervalo = setInterval(() => {
      tempoDecorrido++;
      const minutos = Math.floor(tempoDecorrido / 60);
      const segundos = tempoDecorrido % 60;
      document.getElementById('temporizador').innerText = `Tempo: ${minutos}:${segundos < 10 ? '0' : ''}${segundos}`;
    }, 1000);
  }

  function carregarSimulado() {
    const containerSimulado = document.getElementById('quiz');
    let conteudoSimulado = '';

    for (let i = 0; i < totalQuestoes; i++) {
      conteudoSimulado += `
        <div class="questao" id="questao${i}">
          <h4>${i + 1}. ${questoes[i % questoes.length].pergunta}</h4><br><br>
          <ul class="respostas">
            <li><input type="radio" name="questao${i}" value="a" onclick="marcarQuestao(${i})"> ${questoes[i % questoes.length].respostas.a}</li>
            <li><input type="radio" name="questao${i}" value="b" onclick="marcarQuestao(${i})"> ${questoes[i % questoes.length].respostas.b}</li>
            <li><input type="radio" name="questao${i}" value="c" onclick="marcarQuestao(${i})"> ${questoes[i % questoes.length].respostas.c}</li>
            <li><input type="radio" name="questao${i}" value="d" onclick="marcarQuestao(${i})"> ${questoes[i % questoes.length].respostas.d}</li>
            <li><input type="radio" name="questao${i}" value="e" onclick="marcarQuestao(${i})"> ${questoes[i % questoes.length].respostas.e}</li>
          </ul>
        </div>
      `;
    }

    containerSimulado.innerHTML = conteudoSimulado;
    carregarMenuQuestoes();
    mostrarQuestao(indiceQuestaoAtual);
    iniciarTemporizador();
  }

  function carregarMenuQuestoes() {
    const containerMenu = document.getElementById('menu-questoes');
    let conteudoMenu = '';

    for (let i = 0; i < totalQuestoes; i++) {
      conteudoMenu += `<div id="menu-questao${i}" class="numero-questao questao-nao-respondida" onclick="irParaQuestao(${i})">${i + 1}</div>`;
    }

    containerMenu.innerHTML = conteudoMenu;
  }

  function marcarQuestao(indice) {
    questoesRespondidas[indice] = true;
    document.getElementById(`menu-questao${indice}`).classList.remove('questao-nao-respondida');
    document.getElementById(`menu-questao${indice}`).classList.add('questao-respondida');
    respostasUsuario[indice] = document.querySelector(`input[name="questao${indice}"]:checked`).value;
    atualizarNavegacao();
  }

  function irParaQuestao(indice) {
    indiceQuestaoAtual = indice;
    mostrarQuestao(indiceQuestaoAtual);
  }

  function mostrarQuestao(indice) {
    const questaoAtiva = document.querySelector('.questao.ativa');
    if (questaoAtiva) {
      questaoAtiva.classList.remove('ativa');
    }
    document.getElementById(`questao${indice}`).classList.add('ativa');

    const botaoAnterior = document.getElementById('botao-anterior');
    const botaoSubmit = document.getElementById('botao-submit');
    const botaoProximo = document.getElementById('botao-proximo');

    botaoAnterior.classList.toggle('oculto', indice === 0);
    botaoSubmit.classList.toggle('oculto', !questoesRespondidas[indice]);
    botaoProximo.innerText = indice === totalQuestoes - 1 ? 'Ver Resultado' : 'Próximo';
  }

  function proximaQuestao() {
    if (indiceQuestaoAtual < totalQuestoes - 1) {
      indiceQuestaoAtual++;
      mostrarQuestao(indiceQuestaoAtual);
    } else {
      mostrarResultados();
    }
  }

  function questaoAnterior() {
    if (indiceQuestaoAtual > 0) {
      indiceQuestaoAtual--;
      mostrarQuestao(indiceQuestaoAtual);
    }
  }

  function mostrarResultados() {
    clearInterval(temporizadorIntervalo);
    const containerResultado = document.getElementById('container-resultado');
    const slidesResultado = document.getElementById('slides-resultado');
    slidesResultado.innerHTML = '';
    let acertos = 0;

    questoes.forEach((questao, index) => {
      const respostaSelecionada = respostasUsuario[index];
      const resultado = respostaSelecionada === questao.respostaCorreta ? 'Acertou' : 'Errou';
      const explicacao = resultado === 'Errou' ? questao.explicacao : '';
      
      if (resultado === 'Acertou') {
        acertos++;
        document.getElementById(`menu-questao${index}`).classList.add('questao-respondida');
      }

      slidesResultado.innerHTML += `
        <div class="slide-resultado ${resultado.toLowerCase() === 'acertou' ? 'acertou' : 'errou'}">
          <br><h2>${index + 1}. ${questao.pergunta}</h2>
          <p><br> ${resultado}</p>
          <p>${explicacao}</p>
        </div>
      `;
    });

    slidesResultado.innerHTML += `<br><h3>Você acertou ${acertos} de ${totalQuestoes} questões.</h3>`;
    slidesResultado.innerHTML += `<br><p>Tempo total: ${document.getElementById('temporizador').innerText.split(': ')[1]}</p>`;
    containerResultado.classList.add('ativa');
    containerResultado.style.display = 'block';
  }

  function slideAnterior() {
    const slidesResultado = document.querySelectorAll('.slide-resultado');
    slidesResultado.forEach((slide, index) => {
      slide.classList.remove('ativa');
      if (index === indiceResultadoAtual) {
        slide.classList.add('ativa');
      }
    });

    if (indiceResultadoAtual > 0) {
      indiceResultadoAtual--;
    }
  }

  function slideProximo() {
    const slidesResultado = document.querySelectorAll('.slide-resultado');
    slidesResultado.forEach((slide, index) => {
      slide.classList.remove('ativa');
      if (index === indiceResultadoAtual) {
        slide.classList.add('ativa');
      }
    });

    if (indiceResultadoAtual < slidesResultado.length - 1) {
      indiceResultadoAtual++;
    }
  }

  carregarSimulado();



