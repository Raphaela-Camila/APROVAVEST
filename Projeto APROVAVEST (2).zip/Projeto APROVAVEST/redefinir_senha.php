<?php
// Conectar ao banco de dados
$servername = "localhost";  // Altere conforme necessário
$username = "root";         // Altere conforme necessário
$password = "";             // Altere conforme necessário
$dbname = "banco";          // Altere conforme necessário

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Verificar se os dados foram enviados via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obter os dados do formulário
    $email = $_POST['email'];
    $nova_senha = $_POST['nova_senha'];
    $confirmar_senha = $_POST['confirmar_senha'];

    // Validar se as senhas coincidem
    if ($nova_senha != $confirmar_senha) {
        echo "<script>alert('As senhas não coincidem. Tente novamente.'); window.location.href = 'redefinir_senha.html';</script>";
        exit();
    }

    // Verificar se o e-mail existe no banco de dados
    $sql = "SELECT id FROM usuarios WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // Se o e-mail existir, atualizar a senha (sem hash)
        $update_sql = "UPDATE usuarios SET senha = ? WHERE email = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("ss", $nova_senha, $email);

        if ($update_stmt->execute()) {
            echo "<script>alert('Senha alterada com sucesso!'); window.location.href = 'entrar.html';</script>";
        } else {
            echo "<script>alert('Erro ao atualizar a senha. Tente novamente.'); window.location.href = 'redefinir_senha.html';</script>";
        }
    } else {
        // Se o e-mail não for encontrado
        echo "<script>alert('E-mail não encontrado. Tente novamente.'); window.location.href = 'redefinir_senha.html';</script>";
    }

    $stmt->close();
    $conn->close();
}
?>
