<?php
session_start();
$servername = "localhost";
$username = "root";
$password = ""; 
$dbname = "banco";

// Conectar ao banco de dados
$conn = mysqli_connect($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Verificar se os campos de formulário estão preenchidos
if (empty($_POST['email-login']) || empty($_POST['senha'])) {
    echo "<script>alert('Preencha todos os campos!');</script>";
    var_dump($_POST); // Debug: mostra o que está sendo enviado
    echo "<script>window.location.href='entrar.html';</script>";
    exit();
}

// Preparar e executar a consulta para buscar o usuário
$stmt = $conn->prepare("SELECT nome, nasc, cpf, senha FROM usuarios WHERE email = ?");
$stmt->bind_param("s", $_POST['email-login']);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    $stmt->bind_result($nome, $nasc, $cpf, $stored_senha);
    $stmt->fetch();

    // Verificar se a senha inserida é igual à senha armazenada
    if ($_POST['senha'] === $stored_senha) {
        // Login bem-sucedido, armazena dados na sessão
        $_SESSION['user'] = [
            'nome' => $nome,
            'email' => $_POST['email-login'],
            'nasc' => $nasc,
            'cpf' => $cpf
        ];
        header('Location: home.html'); 
        exit();
    } else {
        echo "<script>alert('Senha incorreta');</script>";
        echo "<script>window.location.href='entrar.html';</script>";
    }
} else {
    echo "<script>alert('Usuário não encontrado');</script>";
    echo "<script>window.location.href='entrar.html';</script>";
}

$stmt->close();
$conn->close();
?>
