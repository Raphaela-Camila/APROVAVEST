<?php
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['user'])) {
    echo json_encode(['error' => 'Usuário não logado']);
    exit();
}

// Retornar os dados do usuário
$user = $_SESSION['user'];
echo json_encode($user);
?>
