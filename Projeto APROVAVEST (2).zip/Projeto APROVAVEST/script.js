// Menu Hamburguer
const menuIcon = document.getElementById('menuIcon');
const menu = document.getElementById('menu');
const closeBtn = document.getElementById('closeBtn');

// Abre/fecha o menu ao clicar no ícone do menu
menuIcon.addEventListener('click', function() {
    menu.classList.toggle('show');
});

// Fecha o menu ao clicar no botão de fechar
closeBtn.addEventListener('click', function() {
    menu.classList.remove('show');
});

// Fecha o menu ao clicar fora dele
document.addEventListener('click', function(event) {
    const isClickInsideMenu = menu.contains(event.target);
    const isClickOnIcon = menuIcon.contains(event.target);

    if (!isClickInsideMenu && !isClickOnIcon) {
        menu.classList.remove('show');
    }
});
// Fim do Menu Hamburguer 


// Entrar e Cadastrar
// Função que roda ao carregar a página
window.onload = function() {
    const hash = window.location.hash;  // Verifica o parâmetro da âncora na URL
    const loginForm = document.getElementById('login-form');
    const signupForm = document.getElementById('signup-form');
    const loginBtn = document.getElementById('login-btn');
    const signupBtn = document.getElementById('signup-btn');

    // Verifica a âncora e alterna entre os formulários
    if (hash === '#signup-form') {
        signupForm.classList.add('active');
        loginForm.classList.remove('active');
        signupBtn.classList.add('selected');
        loginBtn.classList.remove('selected');
    } else if (hash === '#login-form') {
        loginForm.classList.add('active');
        signupForm.classList.remove('active');
        loginBtn.classList.add('selected');
        signupBtn.classList.remove('selected');
    } else {
        // Padrão: exibir o formulário de login
        loginForm.classList.add('active');
        signupForm.classList.remove('active');
        loginBtn.classList.add('selected');
        signupBtn.classList.remove('selected');
    }
};

// Alterna para o formulário de login ao clicar no botão "Entrar"
document.getElementById('login-btn').addEventListener('click', () => {
    document.getElementById('login-form').classList.add('active');
    document.getElementById('signup-form').classList.remove('active');
    document.getElementById('login-btn').classList.add('selected');
    document.getElementById('signup-btn').classList.remove('selected');
    window.location.hash = '#login-form';  // Atualiza a âncora na URL para "login-form"
});

// Alterna para o formulário de cadastro ao clicar no botão "Cadastrar-se"
document.getElementById('signup-btn').addEventListener('click', () => {
    document.getElementById('signup-form').classList.add('active');
    document.getElementById('login-form').classList.remove('active');
    document.getElementById('signup-btn').classList.add('selected');
    document.getElementById('login-btn').classList.remove('selected');
    window.location.hash = '#signup-form';  // Atualiza a âncora na URL para "signup-form"
});



// Fim do entrar e cadastrar


// Quiz 
const questions = [
    {
        question: "A Cartografia é um campo da ciência geográfica que tem diversos ramos de atuação. NÃO é um objeto de estudo da Cartografia?", 
        answers: [
            {text: "os mapas.", correct: false, explanation: "Resposta errada, a resposta correta é a: C. Os satélites não são objetos de estudo da Cartografia, mas sim ferramentas de tecnologia avançada que são utilizadas para produzir imagens, que, por sua vez, podem ser empregadas para levantamentos espaciais diversos."},
            {text: "os croquis.", correct: false, explanation: "Resposta errada, a resposta correta é a: C. Os satélites não são objetos de estudo da Cartografia, mas sim ferramentas de tecnologia avançada que são utilizadas para produzir imagens, que, por sua vez, podem ser empregadas para levantamentos espaciais diversos."},
            {text: "os satélites.", correct: true, explanation: "Parabéns! Resposta correta! Os satélites não são objetos de estudo da Cartografia, mas sim ferramentas de tecnologia avançada que são utilizadas para produzir imagens, que, por sua vez, podem ser empregadas para levantamentos espaciais diversos."},
            {text: "as plantas", correct: false, explanation: "Resposta errada, a resposta correta é a: C. Os satélites não são objetos de estudo da Cartografia, mas sim ferramentas de tecnologia avançada que são utilizadas para produzir imagens, que, por sua vez, podem ser empregadas para levantamentos espaciais diversos."},
            {text: "as cartas", correct: false, explanation: "Resposta errada, a resposta correta é a: C. Os satélites não são objetos de estudo da Cartografia, mas sim ferramentas de tecnologia avançada que são utilizadas para produzir imagens, que, por sua vez, podem ser empregadas para levantamentos espaciais diversos."},
        ]
    },
    {
        question: "Como é chamado o ramo da Cartografia responsável pelo estudo das características físicas da superfície terrestre?",
        answers: [
            {text: "Cartografia Social.", correct: false, explanation: "Resposta errada, a resposta correta é a: B. A Cartografia Sistemática, também chamada de Cartografia Topográfica, é aquela que tem como objetivo a representação espacial de fenômenos atrelados aos aspectos físicos do planeta, como formações geológicas, geomorfológicas e pedológicas."},
            {text: "Cartografia Sistemática", correct: true, explanation: "Parabéns! Resposta correta! A Cartografia Sistemática, também chamada de Cartografia Topográfica, é aquela que tem como objetivo a representação espacial de fenômenos atrelados aos aspectos físicos do planeta, como formações geológicas, geomorfológicas e pedológicas."},
            {text: "Cartografia Contemporânea", correct: false, explanation: "Resposta errada, a resposta correta é a: B. A Cartografia Sistemática, também chamada de Cartografia Topográfica, é aquela que tem como objetivo a representação espacial de fenômenos atrelados aos aspectos físicos do planeta, como formações geológicas, geomorfológicas e pedológicas."},
            {text: "Cartografia Temática", correct: false, explanation: "Resposta errada, a resposta correta é a: B. A Cartografia Sistemática, também chamada de Cartografia Topográfica, é aquela que tem como objetivo a representação espacial de fenômenos atrelados aos aspectos físicos do planeta, como formações geológicas, geomorfológicas e pedológicas."},
            {text: "Cartografia Física", correct: false, explanation: "Resposta errada, a resposta correta é a: B. A Cartografia Sistemática, também chamada de Cartografia Topográfica, é aquela que tem como objetivo a representação espacial de fenômenos atrelados aos aspectos físicos do planeta, como formações geológicas, geomorfológicas e pedológicas."}
        ]
    },
    {
        question: "O mapa é um dos elementos mais comuns de representação cartográfica. Um elemento que NÃO é obrigatório em um mapa é a...", 
        answers: [
            {text: "escala", correct: false, explanation: "Resposta errada, a resposta correta é a: D. A coloração não é um elemento obrigatório de um mapa, visto não há necessidade da variável cor para que um mapa seja um objeto cartográfico. Os quatro elementos que são obrigatórios em um mapa são: título, escala, legenda e orientação."},
            {text: "legenda", correct: false, explanation: "Resposta errada, a resposta correta é a: D. A coloração não é um elemento obrigatório de um mapa, visto não há necessidade da variável cor para que um mapa seja um objeto cartográfico. Os quatro elementos que são obrigatórios em um mapa são: título, escala, legenda e orientação."},
            {text: "orientação", correct: false, explanation: "Resposta errada, a resposta correta é a: D. A coloração não é um elemento obrigatório de um mapa, visto não há necessidade da variável cor para que um mapa seja um objeto cartográfico. Os quatro elementos que são obrigatórios em um mapa são: título, escala, legenda e orientação."},
            {text: "coloração", correct: true, explanation: "Parabéns! Resposta correta! A coloração não é um elemento obrigatório de um mapa, visto não há necessidade da variável cor para que um mapa seja um objeto cartográfico. Os quatro elementos que são obrigatórios em um mapa são: título, escala, legenda e orientação."},
            {text: "titulação", correct: false, explanation: "Resposta errada, a resposta correta é a: D. A coloração não é um elemento obrigatório de um mapa, visto não há necessidade da variável cor para que um mapa seja um objeto cartográfico. Os quatro elementos que são obrigatórios em um mapa são: título, escala, legenda e orientação."},
        ]
    },
    {
        question: "Qual período histórico teve como consequência um grande avanço na Cartografia em razão dos deslocamentos espaciais?",
        answers: [
            {text: "Revolução Verde", correct: false, explanation: "Resposta errada, a resposta correta é a: C. O período das Grandes Navegações, com o avanço dos instrumentos de navegação e a descobertas de novos territórios, possibilitou o desenvolvimento da ciência cartográfica por meio da necessidade de levantamentos geográficos diversos."},
            {text: "Primeira Guerra", correct: false, explanation: "Resposta errada, a resposta correta é a: C. O período das Grandes Navegações, com o avanço dos instrumentos de navegação e a descobertas de novos territórios, possibilitou o desenvolvimento da ciência cartográfica por meio da necessidade de levantamentos geográficos diversos."},
            {text: "Grandes Navegações", correct: true, explanation: "Parabéns! Resposta correta! O período das Grandes Navegações, com o avanço dos instrumentos de navegação e a descobertas de novos territórios, possibilitou o desenvolvimento da ciência cartográfica por meio da necessidade de levantamentos geográficos diversos."},
            {text: "Partilha Africana", correct: false, explanation: "Resposta errada, a resposta correta é a: C. O período das Grandes Navegações, com o avanço dos instrumentos de navegação e a descobertas de novos territórios, possibilitou o desenvolvimento da ciência cartográfica por meio da necessidade de levantamentos geográficos diversos."},
            {text: "Revolução Industrial", correct: false, explanation: "Resposta errada, a resposta correta é a: C. O período das Grandes Navegações, com o avanço dos instrumentos de navegação e a descobertas de novos territórios, possibilitou o desenvolvimento da ciência cartográfica por meio da necessidade de levantamentos geográficos diversos."},
        ]
    },
    {
        question: "As coordenadas geográficas são importantes para o entendimento de um mapa. Elas são formadas por meio de linhas imaginárias chamadas de",
        answers: [
            {text: "Paralelos e meridianos.", correct: true, explanation: "Parabéns! Resposta correta! As coordenadas geográficas são linhas imaginárias dispostas na superfície terrestre que possibilitam a localização de um ponto no espaço global. As linhas horizontais são chamadas de paralelos, e as linhas verticais são chamadas de meridianos."},
            {text: "Latitude e longitude.", correct: false, explanation: "Resposta errada, a resposta correta é a: A. As coordenadas geográficas são linhas imaginárias dispostas na superfície terrestre que possibilitam a localização de um ponto no espaço global. As linhas horizontais são chamadas de paralelos, e as linhas verticais são chamadas de meridianos."},
            {text: "Cônica e cilíndrica.", correct: false, explanation: "Resposta errada, a resposta correta é a: A. As coordenadas geográficas são linhas imaginárias dispostas na superfície terrestre que possibilitam a localização de um ponto no espaço global. As linhas horizontais são chamadas de paralelos, e as linhas verticais são chamadas de meridianos."},
            {text: "Latitude e altitude.", correct: false, explanation: "Resposta errada, a resposta correta é a: A. As coordenadas geográficas são linhas imaginárias dispostas na superfície terrestre que possibilitam a localização de um ponto no espaço global. As linhas horizontais são chamadas de paralelos, e as linhas verticais são chamadas de meridianos."},
            {text: "Verticais e horizontais.", correct: false, explanation: "Resposta errada, a resposta correta é a: A. As coordenadas geográficas são linhas imaginárias dispostas na superfície terrestre que possibilitam a localização de um ponto no espaço global. As linhas horizontais são chamadas de paralelos, e as linhas verticais são chamadas de meridianos."},
        ]
    },
    {
        question: "Assinale a alternativa que não apresenta um produto oriundo dos avanços da Cartografia por meio das inovações tecnológicas modernas:", 
        answers: [
            {text: "Geoprocessamento", correct: false, explanation: "Resposta errada, a resposta correta é a: C. A projeção de Mercator faz parte do passado da Cartografia, quando os mapas ainda eram confeccionados de forma mais tradicional. Já a aerofotogrametria, o geoprocessamento e o sensoriamento remoto são exemplos de recursos modernos da Cartografia."},
            {text: "Sistema de Informação Geográfica.", correct: false, explanation: "Resposta errada, a resposta correta é a: C. A projeção de Mercator faz parte do passado da Cartografia, quando os mapas ainda eram confeccionados de forma mais tradicional. Já a aerofotogrametria, o geoprocessamento e o sensoriamento remoto são exemplos de recursos modernos da Cartografia."},
            {text: "Projeção de Mercator", correct: true, explanation: "Parabéns! Resposta correta. A projeção de Mercator faz parte do passado da Cartografia, quando os mapas ainda eram confeccionados de forma mais tradicional. Já a aerofotogrametria, o geoprocessamento e o sensoriamento remoto são exemplos de recursos modernos da Cartografia."},
            {text: "Sensoriamento remoto", correct: false, explanation: "Resposta errada, a resposta correta é a: C. A projeção de Mercator faz parte do passado da Cartografia, quando os mapas ainda eram confeccionados de forma mais tradicional. Já a aerofotogrametria, o geoprocessamento e o sensoriamento remoto são exemplos de recursos modernos da Cartografia."},
            {text: "Aerofotogrametria", correct: false, explanation: "Resposta errada, a resposta correta é a: C. A projeção de Mercator faz parte do passado da Cartografia, quando os mapas ainda eram confeccionados de forma mais tradicional. Já a aerofotogrametria, o geoprocessamento e o sensoriamento remoto são exemplos de recursos modernos da Cartografia."}
        ]
    },
    {
        question: "O elemento do mapa que é o responsável pela relação entre a distância real da superfície terrestre e a área cartografada é chamado corretamente de", 
        answers: [
            {text: "Coordenada geográfica", correct: false, explanation: "Resposta errada, a resposta correta é a: B. A escala é o elemento obrigatório de uma representação cartográfica que indica a relação matemática entre a distância real do terreno e a distância representada no mapa."},
            {text: "Seta norte", correct: false, explanation: "Resposta errada, a resposta correta é a: B. A escala é o elemento obrigatório de uma representação cartográfica que indica a relação matemática entre a distância real do terreno e a distância representada no mapa."},
            {text: "Título.", correct: false, explanation: "Resposta errada, a resposta correta é a: B. A escala é o elemento obrigatório de uma representação cartográfica que indica a relação matemática entre a distância real do terreno e a distância representada no mapa."},
            {text: "Bússola.", correct: false, explanation: "Resposta errada, a resposta correta é a: B. A escala é o elemento obrigatório de uma representação cartográfica que indica a relação matemática entre a distância real do terreno e a distância representada no mapa."},
            {text: "Escala cartográfica.", correct: true, explanation: "Parabéns! Resposta correta. A escala é o elemento obrigatório de uma representação cartográfica que indica a relação matemática entre a distância real do terreno e a distância representada no mapa."},
        ]
    },
];

const questionElement = document.getElementById("question");
const answerButtons = document.getElementById("answer-buttons");
const nextButton = document.getElementById("next-btn");
const explanationElement = document.getElementById("explanation");

let currentQuestionIndex = 0;
let score = 0;

function startQuiz(){
    currentQuestionIndex = 0;
    score = 0;
    nextButton.innerHTML = "Next";
    showQuestion();
}

function showQuestion(){
    resetState();
    let currentQuestion = questions[currentQuestionIndex];
    let questionNo = currentQuestionIndex + 1;
    questionElement.innerHTML = questionNo + ". " + currentQuestion.question;

    currentQuestion.answers.forEach(answer => {
       const button = document.createElement("button");
       button.innerHTML = answer.text;
       button.classList.add("btn");
       answerButtons.appendChild(button);
       button.dataset.explanation = answer.explanation; // Adiciona a explicação ao botão
       if(answer.correct){
            button.dataset.correct = answer.correct;
       }
       button.addEventListener("click", selectAnswer);
    });
} 

function resetState(){
    nextButton.style.display = "none";
    explanationElement.style.display = "none"; // Oculta a explicação
    explanationElement.innerHTML = "";
    while(answerButtons.firstChild){
        answerButtons.removeChild(answerButtons.firstChild);
    }
}

function selectAnswer(e){
    const selectedBtn = e.target;
    const isCorrect = selectedBtn.dataset.correct === "true";
    if(isCorrect){
        selectedBtn.classList.add("correct");
        score++;
    }else{
        selectedBtn.classList.add("incorrect");
    }
    Array.from(answerButtons.children).forEach(button => {
        if(button.dataset.correct == "true"){
            button.classList.add("correct");
        }
        button.disabled = true;
    });
    
    // Exibe a explicação
    const explanation = selectedBtn.dataset.explanation;
    explanationElement.innerHTML = explanation;
    explanationElement.style.display = "block";
    
    nextButton.style.display = "block"; 
}

function showScore(){
    resetState();
    questionElement.innerHTML = `Sua pontuação é ${score} de ${questions.length}`;
    nextButton.innerHTML = "Jogue novamente";
    nextButton.style.display = "block";
}

function handleNextButton(){
    currentQuestionIndex++;
    if(currentQuestionIndex < questions.length){
        showQuestion();
    }else{
        showScore();
    }
}

nextButton.addEventListener("click", () => {
    if(currentQuestionIndex < questions.length){
        handleNextButton();
    }else{
        startQuiz();
    }
})

startQuiz();


// Fim do Quiz

//Flash Card
let currentIndex = 0;  // Índice atual do slide
const totalCards = 3;  // Número total de flashcards

function flipCard(card) {
    card.classList.toggle('flipped');
}

function updateProgressBar(direction) {
    // Atualiza o índice do carrossel dependendo da direção
    if (direction === 'next') {
        currentIndex = Math.min(currentIndex + 1, totalCards - 1);  // Limite no final
    } else if (direction === 'prev') {
        currentIndex = Math.max(currentIndex - 1, 0);  // Limite no começo
    }

    // Calcula a largura da barra de progresso
    const progressPercentage = ((currentIndex + 1) / totalCards) * 100;
    document.getElementById('progressBar').style.width = progressPercentage + '%';
}

// Função para ler a resposta do flashcard atual
function lerResposta() {
    const respostaAtual = document.querySelector(`.carousel-item:nth-child(${currentIndex + 1}) .card-back p`).textContent;
    const fala = new SpeechSynthesisUtterance(respostaAtual);
    fala.lang = 'pt-BR';
    window.speechSynthesis.speak(fala);
}

// Associa o evento ao botão "Ouvir Resposta"
document.getElementById('btn-ler-resposta').addEventListener('click', lerResposta);
//Fim do flashcard


function togglePerfilWindow(event) {
    event.stopPropagation();  // Impede que o clique no ícone feche a janela
    const perfilJanela = document.getElementById('perfilJanela');
    if (perfilJanela.style.display === 'none' || perfilJanela.style.display === '') {
        perfilJanela.style.display = 'block';
        document.addEventListener('click', closeOnClickOutside);
    } else {
        perfilJanela.style.display = 'none';
        document.removeEventListener('click', closeOnClickOutside);
    }
}

function closeOnClickOutside(event) {
    const perfilJanela = document.getElementById('perfilJanela');
    if (!perfilJanela.contains(event.target)) {
        perfilJanela.style.display = 'none';
        document.removeEventListener('click', closeOnClickOutside);
    }
}