<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil</title>
    <link rel="shortcut icon" href="imagens/logo.png">
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <header>
        <div class="menu-container">
            <div class="menu-icon" id="menuIcon">
                <div class="bar"></div>
                <div class="bar"></div>
                <div class="bar"></div>
            </div>
            <br><br>
            <a href="home.html"><img src="imagens/logo.png" alt="Logo" class="logo"></a>
            <nav class="menu" id="menu">
                <button class="menu-botoes" id="closeBtn">&times;</button>
                <ul><br><br><br>
                    <li><a href="home.html">Início</a></li><br>
                    <li><a href="perfil.html">Perfil</a></li><br>
                    <li><a href="simulados.html">Simulados</a></li><br>
                    <li><a href="chat.html">Chat AprovaVest</a></li><br>
                    <li><a href="sobre.html">Sobre Vestibulares</a></li>
                </ul>
            </nav>
        </div>
        <hr>
    </header><br><br><br>
    
    <a href="home.html" class="back-conteudo" aria-label="Voltar para Geografia">
        <i class="fas fa-arrow-left"></i>
        <span>INÍCIO</span>
    </a>

    <main>
        <center>
            <div class="perfil-container">
                <div class="image-container">
                    <img src="imagens/pefil_foto.png" alt="Foto de Perfil">
                    <p id="profileName" class="profile-name"></p>
                </div>
                <div class="details-container">
                    <div class="info-container">
                        <h2 class="section-title">Dados Pessoais</h2>
                        <div class="personal-info">
                            <p>Email: <span id="profileEmail"></span></p>
                            <p>Data de Nascimento: <span id="profileNasc"></span></p>
                            <p>CPF: <span id="profileCpf"></span></p>
                        </div>
                    </div>
                </div>
                
                <!-- Botão de editar perfil -->
                <button id="editProfileBtn">Editar meus dados</button>

                <!-- Formulário de atualização de dados -->
                <div id="editFormContainer" style="display:none;">
                    <form id="editProfileForm">
                        <div class="personal-info">
                            <label for="email">Email:</label>
                            <input type="email" id="email" name="email" value="" required><br>

                            <label for="nasc">Data de Nascimento:</label>
                            <input type="date" id="nasc" name="nasc" value="" required><br>

                            <label for="cpf">CPF:</label>
                            <input type="text" id="cpf" name="cpf" value="" required><br>

                            <button type="button" id="submitBtn">Atualizar</button>
                        </div>
                    </form>
                </div>
            </div>
        </center>
    </main>
    
    <footer>
        <div class="rodape-container">
            <div class="rodape-sobre">
                <h3>Sobre Nós</h3>
                <p>Somos uma empresa dedicada a fornecer soluções inovadoras para vestibulandos em todas as áreas.</p>
            </div>
            <div class="rodape-links">
                <h3>Links</h3>
                <ul>
                    <li><a href="#">Suporte</a></li>
                    <li><a href="#">Serviços</a></li>
                    <li><a href="#">Contatos</a></li>
                    <li><a href="#">Informações</a></li>
                </ul>
            </div>
            <div class="rodape-social">
                <h3>Siga-nos</h3>
                <a href="#"><i class="fab fa-facebook"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
                <a href="#"><i class="fab fa-linkedin"></i></a>
            </div>
        </div>
        <div class="rodape-final">
            <p>&copy; 2024 AprovaVest. Todos os direitos reservados.</p>
        </div>
    </footer>

    <script src="script.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Chamada AJAX para buscar dados do usuário
            fetch('getUserData.php')
                .then(response => response.json())
                .then(data => {
                    if (data.error) {
                        console.error(data.error);
                        alert("Você precisa estar logado para ver seu perfil.");
                        window.location.href = 'entrar.html'; // Redireciona se não estiver logado
                    } else {
                        // Atualiza a interface com os dados do usuário
                        document.getElementById('profileName').innerText = data.nome;
                        document.getElementById('profileEmail').innerText = data.email;
                        document.getElementById('profileNasc').innerText = data.nasc;
                        document.getElementById('profileCpf').innerText = data.cpf;

                        // Preenche os campos do formulário com os dados atuais
                        document.getElementById('email').value = data.email;
                        document.getElementById('nasc').value = data.nasc;
                        document.getElementById('cpf').value = data.cpf;
                    }
                })
                .catch(error => console.error('Erro ao buscar dados do usuário:', error));

            // Quando o botão "Editar meus dados" for clicado, exibe o formulário de edição
            document.getElementById('editProfileBtn').addEventListener('click', function () {
                document.getElementById('editFormContainer').style.display = 'block';  // Exibe o formulário
                this.style.display = 'none';  // Esconde o botão
            });

            // Envia os dados atualizados ao clicar no botão de atualizar
            document.getElementById('submitBtn').addEventListener('click', function () {
                const email = document.getElementById('email').value;
                const nasc = document.getElementById('nasc').value;
                const cpf = document.getElementById('cpf').value;

                // Cria o objeto com os dados que o usuário alterou
                const dataToUpdate = {};
                if (email) dataToUpdate.email = email;
                if (nasc) dataToUpdate.nasc = nasc;
                if (cpf) dataToUpdate.cpf = cpf;

                // Envia a requisição PUT com os dados alterados
                fetch('atualizarPerfil.php', {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(dataToUpdate)  // Dados que foram alterados
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Dados atualizados com sucesso!');
                        // Recarregar a página ou atualizar os dados na interface
                        window.location.reload();
                    } else {
                        alert('Erro ao atualizar os dados');
                    }
                })
                .catch(error => console.error('Erro ao atualizar os dados:', error));
            });
        });
    </script>
</body>
</html>
