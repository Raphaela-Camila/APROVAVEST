document.getElementById("sendBtn").addEventListener("click", function() {
    const userMessage = document.getElementById("messageInput").value;
    if (userMessage.trim() === "") return;

    // Adiciona a mensagem do usuário ao chatbox
    appendMessage(userMessage, "sent"); // Passa "sent" para o alinhamento

    // Limpa o input
    document.getElementById("messageInput").value = "";

    // Chave da API OpenAI (substitua pela sua)
    const apiKey = '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'; // Insira sua chave da API aqui

    // Enviar a mensagem para a API OpenAI
    fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${apiKey}`
        },
        body: JSON.stringify({
            model: "gpt-3.5-turbo", // ou "gpt-4" se sua chave suportar
            messages: [{ role: "user", content: userMessage }],
        })
    })
    .then(response => response.json())
    .then(data => {
        const botMessage = data.choices[0].message.content;
        appendMessage(botMessage, "received"); // Passa "received" para o alinhamento
    })
    .catch(error => {
        console.error("Erro:", error);
        appendMessage("Ocorreu um erro ao processar sua mensagem.", "received"); // Adiciona como mensagem recebida
    });
});

// Função para adicionar mensagens ao chatbox
function appendMessage(message, type) {
    const chatbox = document.getElementById("chatbox");
    const newMessage = document.createElement("div");
    newMessage.classList.add("message", type); // Adiciona a classe para o tipo de mensagem

    const messageContent = document.createElement("div");
    messageContent.classList.add("message-content");
    messageContent.textContent = type === "sent" ? "Você: " + message : "Professor: " + message; // Formata o texto

    newMessage.appendChild(messageContent);
    chatbox.appendChild(newMessage);
    chatbox.scrollTop = chatbox.scrollHeight; // Rolagem automática para a última mensagem
}

//Acionar o botão de envio ao pressionar "Enter"
        document.getElementById('messageInput').addEventListener('keydown', function(event) {
            if (event.key === 'Enter') {
                event.preventDefault(); // Impede o comportamento padrão de envio de formulário
                document.getElementById('sendBtn').click(); // Simula o clique do botão
            }
        });

        // Evento para o botão de enviar
        document.getElementById('sendBtn').addEventListener('click', sendMessage);

function togglePerfilWindow(event) {
    event.stopPropagation();  // Impede que o clique no ícone feche a janela
    const perfilJanela = document.getElementById('perfilJanela');
    if (perfilJanela.style.display === 'none' || perfilJanela.style.display === '') {
        perfilJanela.style.display = 'block';
        document.addEventListener('click', closeOnClickOutside);
    } else {
        perfilJanela.style.display = 'none';
        document.removeEventListener('click', closeOnClickOutside);
    }
}

function closeOnClickOutside(event) {
    const perfilJanela = document.getElementById('perfilJanela');
    if (!perfilJanela.contains(event.target)) {
        perfilJanela.style.display = 'none';
        document.removeEventListener('click', closeOnClickOutside);
    }
}
